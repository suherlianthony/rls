﻿namespace Remote_EE_Lab
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Label6 = new System.Windows.Forms.Label();
            this.board_2_lbl_C1 = new System.Windows.Forms.Label();
            this.board_2_C1 = new System.Windows.Forms.ComboBox();
            this.board_2_R4 = new System.Windows.Forms.ComboBox();
            this.board_2_lbl_C2 = new System.Windows.Forms.Label();
            this.board_2_lbl_R4 = new System.Windows.Forms.Label();
            this.board_2_C2 = new System.Windows.Forms.ComboBox();
            this.board_2_R3 = new System.Windows.Forms.ComboBox();
            this.board_2_lbl_R2 = new System.Windows.Forms.Label();
            this.board_2_lbl3 = new System.Windows.Forms.Label();
            this.board_2_scope_ch_1_gain = new System.Windows.Forms.ComboBox();
            this.board_2_lbl_2 = new System.Windows.Forms.Label();
            this.board_2_lbl1 = new System.Windows.Forms.Label();
            this.board_2_Ch_1 = new System.Windows.Forms.GroupBox();
            this.board_2_lbl_R3 = new System.Windows.Forms.Label();
            this.board_2_ch2 = new System.Windows.Forms.GroupBox();
            this.board_2_lbl6 = new System.Windows.Forms.Label();
            this.board_2_scope_ch_2_gain = new System.Windows.Forms.ComboBox();
            this.board_2_lbl5 = new System.Windows.Forms.Label();
            this.board_2_lbl4 = new System.Windows.Forms.Label();
            this.board_3_multimeter_refresh = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.lbl_board_4_status = new System.Windows.Forms.Label();
            this.board_4_R1 = new System.Windows.Forms.ComboBox();
            this.board_3_multimeter_output = new System.Windows.Forms.RichTextBox();
            this.Label31 = new System.Windows.Forms.Label();
            this.Diode1 = new System.Windows.Forms.GroupBox();
            this.board4_Diode1_RadioButton2 = new System.Windows.Forms.RadioButton();
            this.board4_Diode1_RadioButton1 = new System.Windows.Forms.RadioButton();
            this.lbl_board_3_status = new System.Windows.Forms.Label();
            this.board_2_Circuit_Control = new System.Windows.Forms.GroupBox();
            this.board_3_R3 = new System.Windows.Forms.ComboBox();
            this.board_3_R2 = new System.Windows.Forms.ComboBox();
            this.PictureBox6 = new System.Windows.Forms.PictureBox();
            this.Board_2 = new System.Windows.Forms.TabPage();
            this.lbl_board_2 = new System.Windows.Forms.Label();
            this.lbl_board_2_status = new System.Windows.Forms.Label();
            this.board_2_R2 = new System.Windows.Forms.ComboBox();
            this.board_2_R1 = new System.Windows.Forms.ComboBox();
            this.board_2_lbl_R1 = new System.Windows.Forms.Label();
            this.board_2_chematic = new System.Windows.Forms.PictureBox();
            this.Diode2 = new System.Windows.Forms.GroupBox();
            this.board4_Diode2_RadioButton2 = new System.Windows.Forms.RadioButton();
            this.board4_Diode2_RadioButton1 = new System.Windows.Forms.RadioButton();
            this.lbl_board_1_status = new System.Windows.Forms.Label();
            this.Circuit_Controls = new System.Windows.Forms.GroupBox();
            this.brd_1_ch2 = new System.Windows.Forms.GroupBox();
            this.board_1_lbl_2 = new System.Windows.Forms.Label();
            this.brd_1_ch_2_gain = new System.Windows.Forms.ComboBox();
            this.lbl_gain_2 = new System.Windows.Forms.Label();
            this.Brd_1_Scope_Ch2 = new System.Windows.Forms.ComboBox();
            this.lbl_Scope_1 = new System.Windows.Forms.Label();
            this.brd_1_ch1 = new System.Windows.Forms.GroupBox();
            this.board_1_lbl_1 = new System.Windows.Forms.Label();
            this.brd_1_ch1_gain = new System.Windows.Forms.ComboBox();
            this.lbl_gain_1 = new System.Windows.Forms.Label();
            this.lbl_scope = new System.Windows.Forms.Label();
            this.Brd_1_Scope = new System.Windows.Forms.ComboBox();
            this.Setup = new System.Windows.Forms.TabControl();
            this.Board_1 = new System.Windows.Forms.TabPage();
            this.lbl5k_1 = new System.Windows.Forms.Label();
            this.lbl_board_1 = new System.Windows.Forms.Label();
            this.lbl_5k = new System.Windows.Forms.Label();
            this.lbl_1k = new System.Windows.Forms.Label();
            this.Brd_1_Res_Select = new System.Windows.Forms.ComboBox();
            this.Lbl_19k = new System.Windows.Forms.Label();
            this.lbl_A = new System.Windows.Forms.Label();
            this.board_1_R3_enable = new System.Windows.Forms.ComboBox();
            this.lbl_B = new System.Windows.Forms.Label();
            this.lbl_D = new System.Windows.Forms.Label();
            this.lbl_C = new System.Windows.Forms.Label();
            this.Board_1_Image = new System.Windows.Forms.PictureBox();
            this.Board3 = new System.Windows.Forms.TabPage();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.Board4 = new System.Windows.Forms.TabPage();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.Board5 = new System.Windows.Forms.TabPage();
            this.Label9 = new System.Windows.Forms.Label();
            this.lbl_board_5_status = new System.Windows.Forms.Label();
            this.board_5_R3 = new System.Windows.Forms.ComboBox();
            this.board_5_R2 = new System.Windows.Forms.ComboBox();
            this.board_5_C1 = new System.Windows.Forms.ComboBox();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.Board6 = new System.Windows.Forms.TabPage();
            this.ResetZ80 = new System.Windows.Forms.GroupBox();
            this.ResetZ80_Button = new System.Windows.Forms.Button();
            this.SelectProgram = new System.Windows.Forms.GroupBox();
            this.ProgramSelector = new System.Windows.Forms.ComboBox();
            this.Label19 = new System.Windows.Forms.Label();
            this.lbl_board_6_status = new System.Windows.Forms.Label();
            this.PictureBox4 = new System.Windows.Forms.PictureBox();
            this.Board7 = new System.Windows.Forms.TabPage();
            this.ClearCheckBox = new System.Windows.Forms.CheckBox();
            this.ClockBox = new System.Windows.Forms.GroupBox();
            this.ConnectClock = new System.Windows.Forms.RadioButton();
            this.DisconnectClock = new System.Windows.Forms.RadioButton();
            this.XOR1 = new System.Windows.Forms.GroupBox();
            this.ConnectXOR1 = new System.Windows.Forms.RadioButton();
            this.BypassXOR1 = new System.Windows.Forms.RadioButton();
            this.XOR2 = new System.Windows.Forms.GroupBox();
            this.ConnectXOR2 = new System.Windows.Forms.RadioButton();
            this.BypassXOR2 = new System.Windows.Forms.RadioButton();
            this.XOR3 = new System.Windows.Forms.GroupBox();
            this.ConnectXOR3 = new System.Windows.Forms.RadioButton();
            this.BypassXOR3 = new System.Windows.Forms.RadioButton();
            this.XOR4 = new System.Windows.Forms.GroupBox();
            this.ConnectXOR4 = new System.Windows.Forms.RadioButton();
            this.BypassXOR4 = new System.Windows.Forms.RadioButton();
            this.XOR5 = new System.Windows.Forms.GroupBox();
            this.ConnectXOR5 = new System.Windows.Forms.RadioButton();
            this.BypassXOR5 = new System.Windows.Forms.RadioButton();
            this.XOR6 = new System.Windows.Forms.GroupBox();
            this.ConnectXOR6 = new System.Windows.Forms.RadioButton();
            this.BypassXOR6 = new System.Windows.Forms.RadioButton();
            this.XOR7 = new System.Windows.Forms.GroupBox();
            this.ConnectXOR7 = new System.Windows.Forms.RadioButton();
            this.BypassXOR7 = new System.Windows.Forms.RadioButton();
            this.PresetD1 = new System.Windows.Forms.ComboBox();
            this.PresetD2 = new System.Windows.Forms.ComboBox();
            this.PresetD3 = new System.Windows.Forms.ComboBox();
            this.PresetD4 = new System.Windows.Forms.ComboBox();
            this.PresetD5 = new System.Windows.Forms.ComboBox();
            this.PresetD6 = new System.Windows.Forms.ComboBox();
            this.PresetD7 = new System.Windows.Forms.ComboBox();
            this.Label25 = new System.Windows.Forms.Label();
            this.lbl_board_7_status = new System.Windows.Forms.Label();
            this.PresetD8 = new System.Windows.Forms.ComboBox();
            this.PictureBox5 = new System.Windows.Forms.PictureBox();
            this.PrintDialog1 = new System.Windows.Forms.PrintDialog();
            this.SerialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.lbl_serial = new System.Windows.Forms.Label();
            this.btn_test_2 = new System.Windows.Forms.Button();
            this.btn_Dev_Test = new System.Windows.Forms.Button();
            this.Serial_Text_Test = new System.Windows.Forms.RichTextBox();
            this.btn_Send_Config = new System.Windows.Forms.Button();
            this.CommControlGroup = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.board_detect = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.board_2_Ch_1.SuspendLayout();
            this.board_2_ch2.SuspendLayout();
            this.Diode1.SuspendLayout();
            this.board_2_Circuit_Control.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox6)).BeginInit();
            this.Board_2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.board_2_chematic)).BeginInit();
            this.Diode2.SuspendLayout();
            this.Circuit_Controls.SuspendLayout();
            this.brd_1_ch2.SuspendLayout();
            this.brd_1_ch1.SuspendLayout();
            this.Setup.SuspendLayout();
            this.Board_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Board_1_Image)).BeginInit();
            this.Board3.SuspendLayout();
            this.GroupBox3.SuspendLayout();
            this.Board4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.Board5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            this.Board6.SuspendLayout();
            this.ResetZ80.SuspendLayout();
            this.SelectProgram.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).BeginInit();
            this.Board7.SuspendLayout();
            this.ClockBox.SuspendLayout();
            this.XOR1.SuspendLayout();
            this.XOR2.SuspendLayout();
            this.XOR3.SuspendLayout();
            this.XOR4.SuspendLayout();
            this.XOR5.SuspendLayout();
            this.XOR6.SuspendLayout();
            this.XOR7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox5)).BeginInit();
            this.CommControlGroup.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(154, 37);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(22, 13);
            this.Label6.TabIndex = 19;
            this.Label6.Text = "mA";
            // 
            // board_2_lbl_C1
            // 
            this.board_2_lbl_C1.AutoSize = true;
            this.board_2_lbl_C1.Location = new System.Drawing.Point(177, 155);
            this.board_2_lbl_C1.Name = "board_2_lbl_C1";
            this.board_2_lbl_C1.Size = new System.Drawing.Size(20, 13);
            this.board_2_lbl_C1.TabIndex = 15;
            this.board_2_lbl_C1.Text = "C1";
            // 
            // board_2_C1
            // 
            this.board_2_C1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_2_C1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_2_C1.Enabled = false;
            this.board_2_C1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_2_C1.FormattingEnabled = true;
            this.board_2_C1.Items.AddRange(new object[] {
            "0.01 uF",
            "0.1   uF",
            "0.22 uF"});
            this.board_2_C1.Location = new System.Drawing.Point(139, 171);
            this.board_2_C1.Name = "board_2_C1";
            this.board_2_C1.Size = new System.Drawing.Size(58, 21);
            this.board_2_C1.TabIndex = 14;
            // 
            // board_2_R4
            // 
            this.board_2_R4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_2_R4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_2_R4.Enabled = false;
            this.board_2_R4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_2_R4.FormattingEnabled = true;
            this.board_2_R4.Items.AddRange(new object[] {
            "1 K",
            "5.1 K",
            "10 K",
            "20 K",
            "27 K"});
            this.board_2_R4.Location = new System.Drawing.Point(349, 196);
            this.board_2_R4.Name = "board_2_R4";
            this.board_2_R4.Size = new System.Drawing.Size(54, 21);
            this.board_2_R4.TabIndex = 4;
            // 
            // board_2_lbl_C2
            // 
            this.board_2_lbl_C2.AutoSize = true;
            this.board_2_lbl_C2.Location = new System.Drawing.Point(205, 73);
            this.board_2_lbl_C2.Name = "board_2_lbl_C2";
            this.board_2_lbl_C2.Size = new System.Drawing.Size(20, 13);
            this.board_2_lbl_C2.TabIndex = 13;
            this.board_2_lbl_C2.Text = "C2";
            // 
            // board_2_lbl_R4
            // 
            this.board_2_lbl_R4.AutoSize = true;
            this.board_2_lbl_R4.Location = new System.Drawing.Point(363, 179);
            this.board_2_lbl_R4.Name = "board_2_lbl_R4";
            this.board_2_lbl_R4.Size = new System.Drawing.Size(21, 13);
            this.board_2_lbl_R4.TabIndex = 5;
            this.board_2_lbl_R4.Text = "R4";
            // 
            // board_2_C2
            // 
            this.board_2_C2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_2_C2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_2_C2.Enabled = false;
            this.board_2_C2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_2_C2.FormattingEnabled = true;
            this.board_2_C2.Items.AddRange(new object[] {
            "0.01 uF",
            "0.1   uF",
            "0.22 uF"});
            this.board_2_C2.Location = new System.Drawing.Point(229, 58);
            this.board_2_C2.Name = "board_2_C2";
            this.board_2_C2.Size = new System.Drawing.Size(65, 21);
            this.board_2_C2.TabIndex = 12;
            // 
            // board_2_R3
            // 
            this.board_2_R3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_2_R3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_2_R3.Enabled = false;
            this.board_2_R3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_2_R3.FormattingEnabled = true;
            this.board_2_R3.Items.AddRange(new object[] {
            "1 K",
            "5.1 K",
            "10 K",
            "20 K",
            "27 K"});
            this.board_2_R3.Location = new System.Drawing.Point(258, 196);
            this.board_2_R3.Name = "board_2_R3";
            this.board_2_R3.Size = new System.Drawing.Size(54, 21);
            this.board_2_R3.TabIndex = 6;
            // 
            // board_2_lbl_R2
            // 
            this.board_2_lbl_R2.AutoSize = true;
            this.board_2_lbl_R2.Location = new System.Drawing.Point(124, 106);
            this.board_2_lbl_R2.Name = "board_2_lbl_R2";
            this.board_2_lbl_R2.Size = new System.Drawing.Size(21, 13);
            this.board_2_lbl_R2.TabIndex = 11;
            this.board_2_lbl_R2.Text = "R2";
            // 
            // board_2_lbl3
            // 
            this.board_2_lbl3.AutoSize = true;
            this.board_2_lbl3.Location = new System.Drawing.Point(5, 97);
            this.board_2_lbl3.Name = "board_2_lbl3";
            this.board_2_lbl3.Size = new System.Drawing.Size(119, 13);
            this.board_2_lbl3.TabIndex = 4;
            this.board_2_lbl3.Text = "Match Gain in Vellemen";
            // 
            // board_2_scope_ch_1_gain
            // 
            this.board_2_scope_ch_1_gain.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_2_scope_ch_1_gain.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_2_scope_ch_1_gain.Enabled = false;
            this.board_2_scope_ch_1_gain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_2_scope_ch_1_gain.FormattingEnabled = true;
            this.board_2_scope_ch_1_gain.Items.AddRange(new object[] {
            "1X",
            "10X"});
            this.board_2_scope_ch_1_gain.Location = new System.Drawing.Point(8, 71);
            this.board_2_scope_ch_1_gain.Name = "board_2_scope_ch_1_gain";
            this.board_2_scope_ch_1_gain.Size = new System.Drawing.Size(104, 21);
            this.board_2_scope_ch_1_gain.TabIndex = 3;
            // 
            // board_2_lbl_2
            // 
            this.board_2_lbl_2.AutoSize = true;
            this.board_2_lbl_2.Location = new System.Drawing.Point(6, 54);
            this.board_2_lbl_2.Name = "board_2_lbl_2";
            this.board_2_lbl_2.Size = new System.Drawing.Size(51, 13);
            this.board_2_lbl_2.TabIndex = 2;
            this.board_2_lbl_2.Text = "Ch1 Gain";
            // 
            // board_2_lbl1
            // 
            this.board_2_lbl1.AutoSize = true;
            this.board_2_lbl1.Location = new System.Drawing.Point(6, 27);
            this.board_2_lbl1.Name = "board_2_lbl1";
            this.board_2_lbl1.Size = new System.Drawing.Size(130, 13);
            this.board_2_lbl1.TabIndex = 0;
            this.board_2_lbl1.Text = "Oscilloscope Position: (IN)";
            // 
            // board_2_Ch_1
            // 
            this.board_2_Ch_1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.board_2_Ch_1.Controls.Add(this.board_2_lbl3);
            this.board_2_Ch_1.Controls.Add(this.board_2_scope_ch_1_gain);
            this.board_2_Ch_1.Controls.Add(this.board_2_lbl_2);
            this.board_2_Ch_1.Controls.Add(this.board_2_lbl1);
            this.board_2_Ch_1.Location = new System.Drawing.Point(19, 36);
            this.board_2_Ch_1.Name = "board_2_Ch_1";
            this.board_2_Ch_1.Size = new System.Drawing.Size(162, 123);
            this.board_2_Ch_1.TabIndex = 4;
            this.board_2_Ch_1.TabStop = false;
            this.board_2_Ch_1.Text = "Scope Channel 1";
            // 
            // board_2_lbl_R3
            // 
            this.board_2_lbl_R3.AutoSize = true;
            this.board_2_lbl_R3.Location = new System.Drawing.Point(273, 181);
            this.board_2_lbl_R3.Name = "board_2_lbl_R3";
            this.board_2_lbl_R3.Size = new System.Drawing.Size(21, 13);
            this.board_2_lbl_R3.TabIndex = 7;
            this.board_2_lbl_R3.Text = "R3";
            // 
            // board_2_ch2
            // 
            this.board_2_ch2.Controls.Add(this.board_2_lbl6);
            this.board_2_ch2.Controls.Add(this.board_2_scope_ch_2_gain);
            this.board_2_ch2.Controls.Add(this.board_2_lbl5);
            this.board_2_ch2.Controls.Add(this.board_2_lbl4);
            this.board_2_ch2.Location = new System.Drawing.Point(19, 205);
            this.board_2_ch2.Name = "board_2_ch2";
            this.board_2_ch2.Size = new System.Drawing.Size(162, 124);
            this.board_2_ch2.TabIndex = 5;
            this.board_2_ch2.TabStop = false;
            this.board_2_ch2.Text = "Scope Channel 2";
            // 
            // board_2_lbl6
            // 
            this.board_2_lbl6.AutoSize = true;
            this.board_2_lbl6.Location = new System.Drawing.Point(6, 98);
            this.board_2_lbl6.Name = "board_2_lbl6";
            this.board_2_lbl6.Size = new System.Drawing.Size(119, 13);
            this.board_2_lbl6.TabIndex = 6;
            this.board_2_lbl6.Text = "Match Gain in Vellemen";
            // 
            // board_2_scope_ch_2_gain
            // 
            this.board_2_scope_ch_2_gain.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_2_scope_ch_2_gain.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_2_scope_ch_2_gain.Enabled = false;
            this.board_2_scope_ch_2_gain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_2_scope_ch_2_gain.FormattingEnabled = true;
            this.board_2_scope_ch_2_gain.Items.AddRange(new object[] {
            "1X",
            "10X"});
            this.board_2_scope_ch_2_gain.Location = new System.Drawing.Point(8, 69);
            this.board_2_scope_ch_2_gain.Name = "board_2_scope_ch_2_gain";
            this.board_2_scope_ch_2_gain.Size = new System.Drawing.Size(104, 21);
            this.board_2_scope_ch_2_gain.TabIndex = 5;
            // 
            // board_2_lbl5
            // 
            this.board_2_lbl5.AutoSize = true;
            this.board_2_lbl5.Location = new System.Drawing.Point(6, 53);
            this.board_2_lbl5.Name = "board_2_lbl5";
            this.board_2_lbl5.Size = new System.Drawing.Size(51, 13);
            this.board_2_lbl5.TabIndex = 4;
            this.board_2_lbl5.Text = "Ch2 Gain";
            // 
            // board_2_lbl4
            // 
            this.board_2_lbl4.AutoSize = true;
            this.board_2_lbl4.Location = new System.Drawing.Point(3, 27);
            this.board_2_lbl4.Name = "board_2_lbl4";
            this.board_2_lbl4.Size = new System.Drawing.Size(142, 13);
            this.board_2_lbl4.TabIndex = 3;
            this.board_2_lbl4.Text = "Oscilloscope Position: (OUT)";
            // 
            // board_3_multimeter_refresh
            // 
            this.board_3_multimeter_refresh.Location = new System.Drawing.Point(7, 62);
            this.board_3_multimeter_refresh.Name = "board_3_multimeter_refresh";
            this.board_3_multimeter_refresh.Size = new System.Drawing.Size(141, 23);
            this.board_3_multimeter_refresh.TabIndex = 20;
            this.board_3_multimeter_refresh.Text = "Refresh Output";
            this.board_3_multimeter_refresh.UseVisualStyleBackColor = true;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(271, 17);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(146, 13);
            this.Label1.TabIndex = 17;
            this.Label1.Text = "Precision Half-Wave Rectifier";
            // 
            // lbl_board_4_status
            // 
            this.lbl_board_4_status.AutoSize = true;
            this.lbl_board_4_status.BackColor = System.Drawing.Color.Red;
            this.lbl_board_4_status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_board_4_status.ForeColor = System.Drawing.Color.White;
            this.lbl_board_4_status.Location = new System.Drawing.Point(6, 26);
            this.lbl_board_4_status.Name = "lbl_board_4_status";
            this.lbl_board_4_status.Size = new System.Drawing.Size(47, 15);
            this.lbl_board_4_status.TabIndex = 16;
            this.lbl_board_4_status.Text = "Inactive";
            // 
            // board_4_R1
            // 
            this.board_4_R1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_4_R1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_4_R1.DropDownWidth = 60;
            this.board_4_R1.Enabled = false;
            this.board_4_R1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_4_R1.FormattingEnabled = true;
            this.board_4_R1.Items.AddRange(new object[] {
            "0.5 k",
            "1 k",
            "1.5 k ",
            "5 k"});
            this.board_4_R1.Location = new System.Drawing.Point(264, 64);
            this.board_4_R1.Name = "board_4_R1";
            this.board_4_R1.Size = new System.Drawing.Size(54, 21);
            this.board_4_R1.TabIndex = 8;
            // 
            // board_3_multimeter_output
            // 
            this.board_3_multimeter_output.Enabled = false;
            this.board_3_multimeter_output.Location = new System.Drawing.Point(6, 34);
            this.board_3_multimeter_output.Name = "board_3_multimeter_output";
            this.board_3_multimeter_output.ReadOnly = true;
            this.board_3_multimeter_output.Size = new System.Drawing.Size(142, 21);
            this.board_3_multimeter_output.TabIndex = 3;
            this.board_3_multimeter_output.Text = "";
            // 
            // Label31
            // 
            this.Label31.AutoSize = true;
            this.Label31.Location = new System.Drawing.Point(271, 17);
            this.Label31.Name = "Label31";
            this.Label31.Size = new System.Drawing.Size(238, 13);
            this.Label31.TabIndex = 17;
            this.Label31.Text = "Current Mirror or Widlar Reducing Current Source";
            // 
            // Diode1
            // 
            this.Diode1.BackColor = System.Drawing.Color.Transparent;
            this.Diode1.Controls.Add(this.board4_Diode1_RadioButton2);
            this.Diode1.Controls.Add(this.board4_Diode1_RadioButton1);
            this.Diode1.Location = new System.Drawing.Point(355, 79);
            this.Diode1.Name = "Diode1";
            this.Diode1.Size = new System.Drawing.Size(62, 71);
            this.Diode1.TabIndex = 22;
            this.Diode1.TabStop = false;
            // 
            // board4_Diode1_RadioButton2
            // 
            this.board4_Diode1_RadioButton2.AutoSize = true;
            this.board4_Diode1_RadioButton2.Enabled = false;
            this.board4_Diode1_RadioButton2.Image = ((System.Drawing.Image)(resources.GetObject("board4_Diode1_RadioButton2.Image")));
            this.board4_Diode1_RadioButton2.Location = new System.Drawing.Point(6, 46);
            this.board4_Diode1_RadioButton2.Name = "board4_Diode1_RadioButton2";
            this.board4_Diode1_RadioButton2.Size = new System.Drawing.Size(53, 22);
            this.board4_Diode1_RadioButton2.TabIndex = 1;
            this.board4_Diode1_RadioButton2.UseVisualStyleBackColor = true;
            // 
            // board4_Diode1_RadioButton1
            // 
            this.board4_Diode1_RadioButton1.AutoSize = true;
            this.board4_Diode1_RadioButton1.Enabled = false;
            this.board4_Diode1_RadioButton1.Image = ((System.Drawing.Image)(resources.GetObject("board4_Diode1_RadioButton1.Image")));
            this.board4_Diode1_RadioButton1.Location = new System.Drawing.Point(6, 19);
            this.board4_Diode1_RadioButton1.Name = "board4_Diode1_RadioButton1";
            this.board4_Diode1_RadioButton1.Size = new System.Drawing.Size(53, 22);
            this.board4_Diode1_RadioButton1.TabIndex = 0;
            this.board4_Diode1_RadioButton1.UseVisualStyleBackColor = true;
            // 
            // lbl_board_3_status
            // 
            this.lbl_board_3_status.AutoSize = true;
            this.lbl_board_3_status.BackColor = System.Drawing.Color.Red;
            this.lbl_board_3_status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_board_3_status.ForeColor = System.Drawing.Color.White;
            this.lbl_board_3_status.Location = new System.Drawing.Point(6, 26);
            this.lbl_board_3_status.Name = "lbl_board_3_status";
            this.lbl_board_3_status.Size = new System.Drawing.Size(47, 15);
            this.lbl_board_3_status.TabIndex = 16;
            this.lbl_board_3_status.Text = "Inactive";
            // 
            // board_2_Circuit_Control
            // 
            this.board_2_Circuit_Control.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.board_2_Circuit_Control.Controls.Add(this.board_2_ch2);
            this.board_2_Circuit_Control.Controls.Add(this.board_2_Ch_1);
            this.board_2_Circuit_Control.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_2_Circuit_Control.Location = new System.Drawing.Point(540, 44);
            this.board_2_Circuit_Control.Name = "board_2_Circuit_Control";
            this.board_2_Circuit_Control.Size = new System.Drawing.Size(200, 340);
            this.board_2_Circuit_Control.TabIndex = 2;
            this.board_2_Circuit_Control.TabStop = false;
            this.board_2_Circuit_Control.Text = "Circuit Controls";
            // 
            // board_3_R3
            // 
            this.board_3_R3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_3_R3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_3_R3.Enabled = false;
            this.board_3_R3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_3_R3.FormattingEnabled = true;
            this.board_3_R3.Items.AddRange(new object[] {
            "short (for current mirror only)",
            "1 K",
            "5.1 K",
            "10 K",
            "20 K"});
            this.board_3_R3.Location = new System.Drawing.Point(307, 302);
            this.board_3_R3.Name = "board_3_R3";
            this.board_3_R3.Size = new System.Drawing.Size(166, 21);
            this.board_3_R3.TabIndex = 4;
            // 
            // board_3_R2
            // 
            this.board_3_R2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_3_R2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_3_R2.Enabled = false;
            this.board_3_R2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_3_R2.FormattingEnabled = true;
            this.board_3_R2.Items.AddRange(new object[] {
            "1 K",
            "5.1 K",
            "10 K",
            "20 K",
            "27 K"});
            this.board_3_R2.Location = new System.Drawing.Point(307, 140);
            this.board_3_R2.Name = "board_3_R2";
            this.board_3_R2.Size = new System.Drawing.Size(54, 21);
            this.board_3_R2.TabIndex = 6;
            // 
            // PictureBox6
            // 
            this.PictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox6.Image")));
            this.PictureBox6.Location = new System.Drawing.Point(3, 44);
            this.PictureBox6.Name = "PictureBox6";
            this.PictureBox6.Size = new System.Drawing.Size(482, 348);
            this.PictureBox6.TabIndex = 3;
            this.PictureBox6.TabStop = false;
            // 
            // Board_2
            // 
            this.Board_2.Controls.Add(this.lbl_board_2);
            this.Board_2.Controls.Add(this.lbl_board_2_status);
            this.Board_2.Controls.Add(this.board_2_Circuit_Control);
            this.Board_2.Controls.Add(this.board_2_lbl_C1);
            this.Board_2.Controls.Add(this.board_2_C1);
            this.Board_2.Controls.Add(this.board_2_R4);
            this.Board_2.Controls.Add(this.board_2_lbl_C2);
            this.Board_2.Controls.Add(this.board_2_lbl_R4);
            this.Board_2.Controls.Add(this.board_2_C2);
            this.Board_2.Controls.Add(this.board_2_R3);
            this.Board_2.Controls.Add(this.board_2_lbl_R2);
            this.Board_2.Controls.Add(this.board_2_lbl_R3);
            this.Board_2.Controls.Add(this.board_2_R2);
            this.Board_2.Controls.Add(this.board_2_R1);
            this.Board_2.Controls.Add(this.board_2_lbl_R1);
            this.Board_2.Controls.Add(this.board_2_chematic);
            this.Board_2.Location = new System.Drawing.Point(4, 22);
            this.Board_2.Name = "Board_2";
            this.Board_2.Padding = new System.Windows.Forms.Padding(3);
            this.Board_2.Size = new System.Drawing.Size(1008, 443);
            this.Board_2.TabIndex = 1;
            this.Board_2.Text = "Experiment 2";
            this.Board_2.UseVisualStyleBackColor = true;
            // 
            // lbl_board_2
            // 
            this.lbl_board_2.AutoSize = true;
            this.lbl_board_2.Location = new System.Drawing.Point(271, 17);
            this.lbl_board_2.Name = "lbl_board_2";
            this.lbl_board_2.Size = new System.Drawing.Size(94, 13);
            this.lbl_board_2.TabIndex = 17;
            this.lbl_board_2.Text = "[ Sallen Key Filter ]";
            // 
            // lbl_board_2_status
            // 
            this.lbl_board_2_status.AutoSize = true;
            this.lbl_board_2_status.BackColor = System.Drawing.Color.Red;
            this.lbl_board_2_status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_board_2_status.ForeColor = System.Drawing.Color.White;
            this.lbl_board_2_status.Location = new System.Drawing.Point(6, 26);
            this.lbl_board_2_status.Name = "lbl_board_2_status";
            this.lbl_board_2_status.Size = new System.Drawing.Size(47, 15);
            this.lbl_board_2_status.TabIndex = 16;
            this.lbl_board_2_status.Text = "Inactive";
            // 
            // board_2_R2
            // 
            this.board_2_R2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_2_R2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_2_R2.Enabled = false;
            this.board_2_R2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_2_R2.FormattingEnabled = true;
            this.board_2_R2.Items.AddRange(new object[] {
            "1 K",
            "5.1 K",
            "10 K",
            "20 K",
            "27 K"});
            this.board_2_R2.Location = new System.Drawing.Point(108, 122);
            this.board_2_R2.Name = "board_2_R2";
            this.board_2_R2.Size = new System.Drawing.Size(54, 21);
            this.board_2_R2.TabIndex = 10;
            // 
            // board_2_R1
            // 
            this.board_2_R1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_2_R1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_2_R1.Enabled = false;
            this.board_2_R1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_2_R1.FormattingEnabled = true;
            this.board_2_R1.Items.AddRange(new object[] {
            "1 K",
            "5.1 K",
            "10 K",
            "20 K",
            "27 K"});
            this.board_2_R1.Location = new System.Drawing.Point(26, 122);
            this.board_2_R1.Name = "board_2_R1";
            this.board_2_R1.Size = new System.Drawing.Size(54, 21);
            this.board_2_R1.TabIndex = 8;
            // 
            // board_2_lbl_R1
            // 
            this.board_2_lbl_R1.AutoSize = true;
            this.board_2_lbl_R1.Location = new System.Drawing.Point(42, 106);
            this.board_2_lbl_R1.Name = "board_2_lbl_R1";
            this.board_2_lbl_R1.Size = new System.Drawing.Size(21, 13);
            this.board_2_lbl_R1.TabIndex = 9;
            this.board_2_lbl_R1.Text = "R1";
            // 
            // board_2_chematic
            // 
            this.board_2_chematic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.board_2_chematic.Image = ((System.Drawing.Image)(resources.GetObject("board_2_chematic.Image")));
            this.board_2_chematic.Location = new System.Drawing.Point(3, 44);
            this.board_2_chematic.Name = "board_2_chematic";
            this.board_2_chematic.Size = new System.Drawing.Size(462, 340);
            this.board_2_chematic.TabIndex = 3;
            this.board_2_chematic.TabStop = false;
            // 
            // Diode2
            // 
            this.Diode2.BackColor = System.Drawing.Color.Transparent;
            this.Diode2.Controls.Add(this.board4_Diode2_RadioButton2);
            this.Diode2.Controls.Add(this.board4_Diode2_RadioButton1);
            this.Diode2.Location = new System.Drawing.Point(445, 278);
            this.Diode2.Name = "Diode2";
            this.Diode2.Size = new System.Drawing.Size(62, 71);
            this.Diode2.TabIndex = 23;
            this.Diode2.TabStop = false;
            // 
            // board4_Diode2_RadioButton2
            // 
            this.board4_Diode2_RadioButton2.AutoSize = true;
            this.board4_Diode2_RadioButton2.Enabled = false;
            this.board4_Diode2_RadioButton2.Image = ((System.Drawing.Image)(resources.GetObject("board4_Diode2_RadioButton2.Image")));
            this.board4_Diode2_RadioButton2.Location = new System.Drawing.Point(6, 46);
            this.board4_Diode2_RadioButton2.Name = "board4_Diode2_RadioButton2";
            this.board4_Diode2_RadioButton2.Size = new System.Drawing.Size(53, 22);
            this.board4_Diode2_RadioButton2.TabIndex = 1;
            this.board4_Diode2_RadioButton2.TabStop = true;
            this.board4_Diode2_RadioButton2.UseVisualStyleBackColor = true;
            // 
            // board4_Diode2_RadioButton1
            // 
            this.board4_Diode2_RadioButton1.AutoSize = true;
            this.board4_Diode2_RadioButton1.Enabled = false;
            this.board4_Diode2_RadioButton1.Image = ((System.Drawing.Image)(resources.GetObject("board4_Diode2_RadioButton1.Image")));
            this.board4_Diode2_RadioButton1.Location = new System.Drawing.Point(6, 19);
            this.board4_Diode2_RadioButton1.Name = "board4_Diode2_RadioButton1";
            this.board4_Diode2_RadioButton1.Size = new System.Drawing.Size(53, 22);
            this.board4_Diode2_RadioButton1.TabIndex = 0;
            this.board4_Diode2_RadioButton1.TabStop = true;
            this.board4_Diode2_RadioButton1.UseVisualStyleBackColor = true;
            // 
            // lbl_board_1_status
            // 
            this.lbl_board_1_status.AutoSize = true;
            this.lbl_board_1_status.BackColor = System.Drawing.Color.Red;
            this.lbl_board_1_status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_board_1_status.ForeColor = System.Drawing.Color.White;
            this.lbl_board_1_status.Location = new System.Drawing.Point(6, 26);
            this.lbl_board_1_status.Name = "lbl_board_1_status";
            this.lbl_board_1_status.Size = new System.Drawing.Size(47, 15);
            this.lbl_board_1_status.TabIndex = 12;
            this.lbl_board_1_status.Text = "Inactive";
            // 
            // Circuit_Controls
            // 
            this.Circuit_Controls.Controls.Add(this.brd_1_ch2);
            this.Circuit_Controls.Controls.Add(this.brd_1_ch1);
            this.Circuit_Controls.Location = new System.Drawing.Point(470, 44);
            this.Circuit_Controls.Name = "Circuit_Controls";
            this.Circuit_Controls.Size = new System.Drawing.Size(200, 359);
            this.Circuit_Controls.TabIndex = 2;
            this.Circuit_Controls.TabStop = false;
            this.Circuit_Controls.Text = "Circuit Controls";
            // 
            // brd_1_ch2
            // 
            this.brd_1_ch2.Controls.Add(this.board_1_lbl_2);
            this.brd_1_ch2.Controls.Add(this.brd_1_ch_2_gain);
            this.brd_1_ch2.Controls.Add(this.lbl_gain_2);
            this.brd_1_ch2.Controls.Add(this.Brd_1_Scope_Ch2);
            this.brd_1_ch2.Controls.Add(this.lbl_Scope_1);
            this.brd_1_ch2.Location = new System.Drawing.Point(19, 205);
            this.brd_1_ch2.Name = "brd_1_ch2";
            this.brd_1_ch2.Size = new System.Drawing.Size(162, 139);
            this.brd_1_ch2.TabIndex = 5;
            this.brd_1_ch2.TabStop = false;
            this.brd_1_ch2.Text = "Scope Channel 2";
            // 
            // board_1_lbl_2
            // 
            this.board_1_lbl_2.AutoSize = true;
            this.board_1_lbl_2.Location = new System.Drawing.Point(6, 109);
            this.board_1_lbl_2.Name = "board_1_lbl_2";
            this.board_1_lbl_2.Size = new System.Drawing.Size(119, 13);
            this.board_1_lbl_2.TabIndex = 6;
            this.board_1_lbl_2.Text = "Match Gain in Vellemen";
            // 
            // brd_1_ch_2_gain
            // 
            this.brd_1_ch_2_gain.BackColor = System.Drawing.SystemColors.ControlLight;
            this.brd_1_ch_2_gain.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.brd_1_ch_2_gain.Enabled = false;
            this.brd_1_ch_2_gain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.brd_1_ch_2_gain.FormattingEnabled = true;
            this.brd_1_ch_2_gain.Items.AddRange(new object[] {
            "1X",
            "10X"});
            this.brd_1_ch_2_gain.Location = new System.Drawing.Point(6, 85);
            this.brd_1_ch_2_gain.Name = "brd_1_ch_2_gain";
            this.brd_1_ch_2_gain.Size = new System.Drawing.Size(104, 21);
            this.brd_1_ch_2_gain.TabIndex = 5;
            // 
            // lbl_gain_2
            // 
            this.lbl_gain_2.AutoSize = true;
            this.lbl_gain_2.Location = new System.Drawing.Point(6, 67);
            this.lbl_gain_2.Name = "lbl_gain_2";
            this.lbl_gain_2.Size = new System.Drawing.Size(51, 13);
            this.lbl_gain_2.TabIndex = 4;
            this.lbl_gain_2.Text = "Ch2 Gain";
            // 
            // Brd_1_Scope_Ch2
            // 
            this.Brd_1_Scope_Ch2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Brd_1_Scope_Ch2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Brd_1_Scope_Ch2.Enabled = false;
            this.Brd_1_Scope_Ch2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Brd_1_Scope_Ch2.FormattingEnabled = true;
            this.Brd_1_Scope_Ch2.Items.AddRange(new object[] {
            "(A)",
            "(B)",
            "(C)",
            "(D)"});
            this.Brd_1_Scope_Ch2.Location = new System.Drawing.Point(6, 43);
            this.Brd_1_Scope_Ch2.Name = "Brd_1_Scope_Ch2";
            this.Brd_1_Scope_Ch2.Size = new System.Drawing.Size(104, 21);
            this.Brd_1_Scope_Ch2.TabIndex = 2;
            // 
            // lbl_Scope_1
            // 
            this.lbl_Scope_1.AutoSize = true;
            this.lbl_Scope_1.Location = new System.Drawing.Point(3, 27);
            this.lbl_Scope_1.Name = "lbl_Scope_1";
            this.lbl_Scope_1.Size = new System.Drawing.Size(107, 13);
            this.lbl_Scope_1.TabIndex = 3;
            this.lbl_Scope_1.Text = "Oscilloscope Position";
            // 
            // brd_1_ch1
            // 
            this.brd_1_ch1.Controls.Add(this.board_1_lbl_1);
            this.brd_1_ch1.Controls.Add(this.brd_1_ch1_gain);
            this.brd_1_ch1.Controls.Add(this.lbl_gain_1);
            this.brd_1_ch1.Controls.Add(this.lbl_scope);
            this.brd_1_ch1.Controls.Add(this.Brd_1_Scope);
            this.brd_1_ch1.Location = new System.Drawing.Point(19, 36);
            this.brd_1_ch1.Name = "brd_1_ch1";
            this.brd_1_ch1.Size = new System.Drawing.Size(162, 135);
            this.brd_1_ch1.TabIndex = 4;
            this.brd_1_ch1.TabStop = false;
            this.brd_1_ch1.Text = "Scope Channel 1";
            // 
            // board_1_lbl_1
            // 
            this.board_1_lbl_1.AutoSize = true;
            this.board_1_lbl_1.Location = new System.Drawing.Point(6, 108);
            this.board_1_lbl_1.Name = "board_1_lbl_1";
            this.board_1_lbl_1.Size = new System.Drawing.Size(119, 13);
            this.board_1_lbl_1.TabIndex = 4;
            this.board_1_lbl_1.Text = "Match Gain in Vellemen";
            // 
            // brd_1_ch1_gain
            // 
            this.brd_1_ch1_gain.BackColor = System.Drawing.SystemColors.ControlLight;
            this.brd_1_ch1_gain.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.brd_1_ch1_gain.Enabled = false;
            this.brd_1_ch1_gain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.brd_1_ch1_gain.FormattingEnabled = true;
            this.brd_1_ch1_gain.Items.AddRange(new object[] {
            "1X",
            "10X"});
            this.brd_1_ch1_gain.Location = new System.Drawing.Point(9, 84);
            this.brd_1_ch1_gain.Name = "brd_1_ch1_gain";
            this.brd_1_ch1_gain.Size = new System.Drawing.Size(104, 21);
            this.brd_1_ch1_gain.TabIndex = 3;
            // 
            // lbl_gain_1
            // 
            this.lbl_gain_1.AutoSize = true;
            this.lbl_gain_1.Location = new System.Drawing.Point(6, 68);
            this.lbl_gain_1.Name = "lbl_gain_1";
            this.lbl_gain_1.Size = new System.Drawing.Size(51, 13);
            this.lbl_gain_1.TabIndex = 2;
            this.lbl_gain_1.Text = "Ch1 Gain";
            // 
            // lbl_scope
            // 
            this.lbl_scope.AutoSize = true;
            this.lbl_scope.Location = new System.Drawing.Point(6, 27);
            this.lbl_scope.Name = "lbl_scope";
            this.lbl_scope.Size = new System.Drawing.Size(107, 13);
            this.lbl_scope.TabIndex = 0;
            this.lbl_scope.Text = "Oscilloscope Position";
            // 
            // Brd_1_Scope
            // 
            this.Brd_1_Scope.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Brd_1_Scope.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Brd_1_Scope.Enabled = false;
            this.Brd_1_Scope.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Brd_1_Scope.FormattingEnabled = true;
            this.Brd_1_Scope.Items.AddRange(new object[] {
            "(A)",
            "(B)",
            "(C)",
            "(D)"});
            this.Brd_1_Scope.Location = new System.Drawing.Point(9, 43);
            this.Brd_1_Scope.Name = "Brd_1_Scope";
            this.Brd_1_Scope.Size = new System.Drawing.Size(104, 21);
            this.Brd_1_Scope.TabIndex = 1;
            this.Brd_1_Scope.SelectedIndexChanged += new System.EventHandler(this.Brd_1_Scope_SelectedIndexChanged_1);
            // 
            // Setup
            // 
            this.Setup.Controls.Add(this.Board_1);
            this.Setup.Controls.Add(this.Board_2);
            this.Setup.Controls.Add(this.Board3);
            this.Setup.Controls.Add(this.Board4);
            this.Setup.Controls.Add(this.Board5);
            this.Setup.Controls.Add(this.Board6);
            this.Setup.Controls.Add(this.Board7);
            this.Setup.Controls.Add(this.tabPage1);
            this.Setup.Location = new System.Drawing.Point(17, 88);
            this.Setup.Name = "Setup";
            this.Setup.SelectedIndex = 0;
            this.Setup.Size = new System.Drawing.Size(1016, 469);
            this.Setup.TabIndex = 7;
            this.Setup.Resize += new System.EventHandler(this.Setup_Resize);
            // 
            // Board_1
            // 
            this.Board_1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Board_1.Controls.Add(this.lbl_board_1_status);
            this.Board_1.Controls.Add(this.Circuit_Controls);
            this.Board_1.Controls.Add(this.lbl5k_1);
            this.Board_1.Controls.Add(this.lbl_board_1);
            this.Board_1.Controls.Add(this.lbl_5k);
            this.Board_1.Controls.Add(this.lbl_1k);
            this.Board_1.Controls.Add(this.Brd_1_Res_Select);
            this.Board_1.Controls.Add(this.Lbl_19k);
            this.Board_1.Controls.Add(this.lbl_A);
            this.Board_1.Controls.Add(this.board_1_R3_enable);
            this.Board_1.Controls.Add(this.lbl_B);
            this.Board_1.Controls.Add(this.lbl_D);
            this.Board_1.Controls.Add(this.lbl_C);
            this.Board_1.Controls.Add(this.Board_1_Image);
            this.Board_1.Location = new System.Drawing.Point(4, 22);
            this.Board_1.Name = "Board_1";
            this.Board_1.Padding = new System.Windows.Forms.Padding(3);
            this.Board_1.Size = new System.Drawing.Size(1008, 443);
            this.Board_1.TabIndex = 0;
            this.Board_1.Text = "Experiment 1";
            // 
            // lbl5k_1
            // 
            this.lbl5k_1.AutoSize = true;
            this.lbl5k_1.Location = new System.Drawing.Point(288, 181);
            this.lbl5k_1.Name = "lbl5k_1";
            this.lbl5k_1.Size = new System.Drawing.Size(22, 13);
            this.lbl5k_1.TabIndex = 11;
            this.lbl5k_1.Text = "5 k";
            // 
            // lbl_board_1
            // 
            this.lbl_board_1.AutoSize = true;
            this.lbl_board_1.Location = new System.Drawing.Point(275, 14);
            this.lbl_board_1.Name = "lbl_board_1";
            this.lbl_board_1.Size = new System.Drawing.Size(113, 13);
            this.lbl_board_1.TabIndex = 0;
            this.lbl_board_1.Text = "[ Two Stage Amplifier ]";
            // 
            // lbl_5k
            // 
            this.lbl_5k.AutoSize = true;
            this.lbl_5k.Location = new System.Drawing.Point(237, 109);
            this.lbl_5k.Name = "lbl_5k";
            this.lbl_5k.Size = new System.Drawing.Size(22, 13);
            this.lbl_5k.TabIndex = 10;
            this.lbl_5k.Text = "5 k";
            // 
            // lbl_1k
            // 
            this.lbl_1k.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_1k.AutoSize = true;
            this.lbl_1k.Location = new System.Drawing.Point(54, 195);
            this.lbl_1k.Name = "lbl_1k";
            this.lbl_1k.Size = new System.Drawing.Size(22, 13);
            this.lbl_1k.TabIndex = 9;
            this.lbl_1k.Text = "1 k";
            // 
            // Brd_1_Res_Select
            // 
            this.Brd_1_Res_Select.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Brd_1_Res_Select.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Brd_1_Res_Select.Enabled = false;
            this.Brd_1_Res_Select.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Brd_1_Res_Select.FormattingEnabled = true;
            this.Brd_1_Res_Select.Items.AddRange(new object[] {
            "1 K",
            "2 K",
            "3 K",
            "4 K",
            "5 K",
            "6 K",
            "7 K",
            "8 K",
            "9 K",
            "10 K",
            "short"});
            this.Brd_1_Res_Select.Location = new System.Drawing.Point(287, 76);
            this.Brd_1_Res_Select.Name = "Brd_1_Res_Select";
            this.Brd_1_Res_Select.Size = new System.Drawing.Size(64, 21);
            this.Brd_1_Res_Select.TabIndex = 1;
            // 
            // Lbl_19k
            // 
            this.Lbl_19k.AutoSize = true;
            this.Lbl_19k.Location = new System.Drawing.Point(108, 184);
            this.Lbl_19k.Name = "Lbl_19k";
            this.Lbl_19k.Size = new System.Drawing.Size(28, 13);
            this.Lbl_19k.TabIndex = 8;
            this.Lbl_19k.Text = "19 k";
            // 
            // lbl_A
            // 
            this.lbl_A.AutoSize = true;
            this.lbl_A.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_A.Location = new System.Drawing.Point(63, 109);
            this.lbl_A.Name = "lbl_A";
            this.lbl_A.Size = new System.Drawing.Size(20, 13);
            this.lbl_A.TabIndex = 3;
            this.lbl_A.Text = "(A)";
            // 
            // board_1_R3_enable
            // 
            this.board_1_R3_enable.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_1_R3_enable.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_1_R3_enable.Enabled = false;
            this.board_1_R3_enable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_1_R3_enable.FormattingEnabled = true;
            this.board_1_R3_enable.Items.AddRange(new object[] {
            "5 k",
            "Open"});
            this.board_1_R3_enable.Location = new System.Drawing.Point(219, 135);
            this.board_1_R3_enable.Name = "board_1_R3_enable";
            this.board_1_R3_enable.Size = new System.Drawing.Size(52, 21);
            this.board_1_R3_enable.TabIndex = 7;
            // 
            // lbl_B
            // 
            this.lbl_B.AutoSize = true;
            this.lbl_B.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_B.Location = new System.Drawing.Point(171, 119);
            this.lbl_B.Name = "lbl_B";
            this.lbl_B.Size = new System.Drawing.Size(20, 13);
            this.lbl_B.TabIndex = 4;
            this.lbl_B.Text = "(B)";
            // 
            // lbl_D
            // 
            this.lbl_D.AutoSize = true;
            this.lbl_D.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_D.Location = new System.Drawing.Point(402, 143);
            this.lbl_D.Name = "lbl_D";
            this.lbl_D.Size = new System.Drawing.Size(21, 13);
            this.lbl_D.TabIndex = 6;
            this.lbl_D.Text = "(D)";
            // 
            // lbl_C
            // 
            this.lbl_C.AutoSize = true;
            this.lbl_C.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_C.Location = new System.Drawing.Point(284, 160);
            this.lbl_C.Name = "lbl_C";
            this.lbl_C.Size = new System.Drawing.Size(20, 13);
            this.lbl_C.TabIndex = 5;
            this.lbl_C.Text = "(C)";
            // 
            // Board_1_Image
            // 
            this.Board_1_Image.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Board_1_Image.Image = ((System.Drawing.Image)(resources.GetObject("Board_1_Image.Image")));
            this.Board_1_Image.Location = new System.Drawing.Point(3, 44);
            this.Board_1_Image.Name = "Board_1_Image";
            this.Board_1_Image.Size = new System.Drawing.Size(450, 359);
            this.Board_1_Image.TabIndex = 0;
            this.Board_1_Image.TabStop = false;
            // 
            // Board3
            // 
            this.Board3.Controls.Add(this.GroupBox3);
            this.Board3.Controls.Add(this.Label31);
            this.Board3.Controls.Add(this.lbl_board_3_status);
            this.Board3.Controls.Add(this.board_3_R3);
            this.Board3.Controls.Add(this.board_3_R2);
            this.Board3.Controls.Add(this.PictureBox6);
            this.Board3.Location = new System.Drawing.Point(4, 22);
            this.Board3.Name = "Board3";
            this.Board3.Padding = new System.Windows.Forms.Padding(3);
            this.Board3.Size = new System.Drawing.Size(1008, 443);
            this.Board3.TabIndex = 7;
            this.Board3.Text = "Experiment 3";
            this.Board3.UseVisualStyleBackColor = true;
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.board_3_multimeter_refresh);
            this.GroupBox3.Controls.Add(this.Label6);
            this.GroupBox3.Controls.Add(this.board_3_multimeter_output);
            this.GroupBox3.Location = new System.Drawing.Point(524, 151);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(200, 100);
            this.GroupBox3.TabIndex = 19;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Multimeter Reading";
            // 
            // Board4
            // 
            this.Board4.Controls.Add(this.Diode2);
            this.Board4.Controls.Add(this.Diode1);
            this.Board4.Controls.Add(this.Label1);
            this.Board4.Controls.Add(this.lbl_board_4_status);
            this.Board4.Controls.Add(this.board_4_R1);
            this.Board4.Controls.Add(this.PictureBox1);
            this.Board4.Location = new System.Drawing.Point(4, 22);
            this.Board4.Name = "Board4";
            this.Board4.Padding = new System.Windows.Forms.Padding(3);
            this.Board4.Size = new System.Drawing.Size(1008, 443);
            this.Board4.TabIndex = 2;
            this.Board4.Text = "Experiment 4";
            this.Board4.UseVisualStyleBackColor = true;
            // 
            // PictureBox1
            // 
            this.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox1.Image")));
            this.PictureBox1.Location = new System.Drawing.Point(3, 44);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(842, 360);
            this.PictureBox1.TabIndex = 3;
            this.PictureBox1.TabStop = false;
            // 
            // Board5
            // 
            this.Board5.Controls.Add(this.Label9);
            this.Board5.Controls.Add(this.lbl_board_5_status);
            this.Board5.Controls.Add(this.board_5_R3);
            this.Board5.Controls.Add(this.board_5_R2);
            this.Board5.Controls.Add(this.board_5_C1);
            this.Board5.Controls.Add(this.PictureBox3);
            this.Board5.Location = new System.Drawing.Point(4, 22);
            this.Board5.Name = "Board5";
            this.Board5.Padding = new System.Windows.Forms.Padding(3);
            this.Board5.Size = new System.Drawing.Size(1008, 443);
            this.Board5.TabIndex = 4;
            this.Board5.Text = "Experiment 5";
            this.Board5.UseVisualStyleBackColor = true;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(271, 17);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(240, 13);
            this.Label9.TabIndex = 17;
            this.Label9.Text = "Integrator With Shunt Resistor vs. Low-Pass Filter";
            // 
            // lbl_board_5_status
            // 
            this.lbl_board_5_status.AutoSize = true;
            this.lbl_board_5_status.BackColor = System.Drawing.Color.Red;
            this.lbl_board_5_status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_board_5_status.ForeColor = System.Drawing.Color.White;
            this.lbl_board_5_status.Location = new System.Drawing.Point(6, 26);
            this.lbl_board_5_status.Name = "lbl_board_5_status";
            this.lbl_board_5_status.Size = new System.Drawing.Size(47, 15);
            this.lbl_board_5_status.TabIndex = 16;
            this.lbl_board_5_status.Text = "Inactive";
            // 
            // board_5_R3
            // 
            this.board_5_R3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_5_R3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_5_R3.Enabled = false;
            this.board_5_R3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_5_R3.FormattingEnabled = true;
            this.board_5_R3.Items.AddRange(new object[] {
            "Open",
            "10 k"});
            this.board_5_R3.Location = new System.Drawing.Point(408, 256);
            this.board_5_R3.Name = "board_5_R3";
            this.board_5_R3.Size = new System.Drawing.Size(65, 21);
            this.board_5_R3.TabIndex = 4;
            // 
            // board_5_R2
            // 
            this.board_5_R2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_5_R2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_5_R2.Enabled = false;
            this.board_5_R2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_5_R2.FormattingEnabled = true;
            this.board_5_R2.Items.AddRange(new object[] {
            "10 k",
            "20 k"});
            this.board_5_R2.Location = new System.Drawing.Point(246, 86);
            this.board_5_R2.Name = "board_5_R2";
            this.board_5_R2.Size = new System.Drawing.Size(65, 21);
            this.board_5_R2.TabIndex = 12;
            // 
            // board_5_C1
            // 
            this.board_5_C1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.board_5_C1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.board_5_C1.Enabled = false;
            this.board_5_C1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_5_C1.FormattingEnabled = true;
            this.board_5_C1.Items.AddRange(new object[] {
            "0.22 uF",
            "0.01 uF"});
            this.board_5_C1.Location = new System.Drawing.Point(362, 144);
            this.board_5_C1.Name = "board_5_C1";
            this.board_5_C1.Size = new System.Drawing.Size(65, 21);
            this.board_5_C1.TabIndex = 8;
            // 
            // PictureBox3
            // 
            this.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox3.Image")));
            this.PictureBox3.Location = new System.Drawing.Point(3, 44);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(842, 368);
            this.PictureBox3.TabIndex = 3;
            this.PictureBox3.TabStop = false;
            // 
            // Board6
            // 
            this.Board6.Controls.Add(this.ResetZ80);
            this.Board6.Controls.Add(this.SelectProgram);
            this.Board6.Controls.Add(this.Label19);
            this.Board6.Controls.Add(this.lbl_board_6_status);
            this.Board6.Controls.Add(this.PictureBox4);
            this.Board6.Location = new System.Drawing.Point(4, 22);
            this.Board6.Name = "Board6";
            this.Board6.Padding = new System.Windows.Forms.Padding(3);
            this.Board6.Size = new System.Drawing.Size(1008, 443);
            this.Board6.TabIndex = 5;
            this.Board6.Text = "Experiment 6";
            this.Board6.UseVisualStyleBackColor = true;
            // 
            // ResetZ80
            // 
            this.ResetZ80.Controls.Add(this.ResetZ80_Button);
            this.ResetZ80.Location = new System.Drawing.Point(736, 214);
            this.ResetZ80.Name = "ResetZ80";
            this.ResetZ80.Size = new System.Drawing.Size(109, 78);
            this.ResetZ80.TabIndex = 19;
            this.ResetZ80.TabStop = false;
            this.ResetZ80.Text = "Reset Z80";
            // 
            // ResetZ80_Button
            // 
            this.ResetZ80_Button.Location = new System.Drawing.Point(6, 32);
            this.ResetZ80_Button.Name = "ResetZ80_Button";
            this.ResetZ80_Button.Size = new System.Drawing.Size(97, 23);
            this.ResetZ80_Button.TabIndex = 0;
            this.ResetZ80_Button.Text = "Reset";
            this.ResetZ80_Button.UseVisualStyleBackColor = true;
            // 
            // SelectProgram
            // 
            this.SelectProgram.Controls.Add(this.ProgramSelector);
            this.SelectProgram.Location = new System.Drawing.Point(736, 120);
            this.SelectProgram.Name = "SelectProgram";
            this.SelectProgram.Size = new System.Drawing.Size(109, 79);
            this.SelectProgram.TabIndex = 18;
            this.SelectProgram.TabStop = false;
            this.SelectProgram.Text = "Select Program";
            // 
            // ProgramSelector
            // 
            this.ProgramSelector.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ProgramSelector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ProgramSelector.Enabled = false;
            this.ProgramSelector.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ProgramSelector.FormattingEnabled = true;
            this.ProgramSelector.Items.AddRange(new object[] {
            "Program A",
            "Program B",
            "Program C",
            "Program D",
            "Program E"});
            this.ProgramSelector.Location = new System.Drawing.Point(6, 32);
            this.ProgramSelector.Name = "ProgramSelector";
            this.ProgramSelector.Size = new System.Drawing.Size(97, 21);
            this.ProgramSelector.TabIndex = 12;
            this.ProgramSelector.SelectedIndexChanged += new System.EventHandler(this.ProgramSelector_SelectedIndexChanged);
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Location = new System.Drawing.Point(271, 17);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(175, 13);
            this.Label19.TabIndex = 17;
            this.Label19.Text = "Debugging a Microprocessor Circuit";
            // 
            // lbl_board_6_status
            // 
            this.lbl_board_6_status.AutoSize = true;
            this.lbl_board_6_status.BackColor = System.Drawing.Color.Red;
            this.lbl_board_6_status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_board_6_status.ForeColor = System.Drawing.Color.White;
            this.lbl_board_6_status.Location = new System.Drawing.Point(6, 26);
            this.lbl_board_6_status.Name = "lbl_board_6_status";
            this.lbl_board_6_status.Size = new System.Drawing.Size(47, 15);
            this.lbl_board_6_status.TabIndex = 16;
            this.lbl_board_6_status.Text = "Inactive";
            // 
            // PictureBox4
            // 
            this.PictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox4.Image")));
            this.PictureBox4.Location = new System.Drawing.Point(3, 44);
            this.PictureBox4.Name = "PictureBox4";
            this.PictureBox4.Size = new System.Drawing.Size(724, 368);
            this.PictureBox4.TabIndex = 3;
            this.PictureBox4.TabStop = false;
            // 
            // Board7
            // 
            this.Board7.AutoScroll = true;
            this.Board7.Controls.Add(this.ClearCheckBox);
            this.Board7.Controls.Add(this.ClockBox);
            this.Board7.Controls.Add(this.XOR1);
            this.Board7.Controls.Add(this.XOR2);
            this.Board7.Controls.Add(this.XOR3);
            this.Board7.Controls.Add(this.XOR4);
            this.Board7.Controls.Add(this.XOR5);
            this.Board7.Controls.Add(this.XOR6);
            this.Board7.Controls.Add(this.XOR7);
            this.Board7.Controls.Add(this.PresetD1);
            this.Board7.Controls.Add(this.PresetD2);
            this.Board7.Controls.Add(this.PresetD3);
            this.Board7.Controls.Add(this.PresetD4);
            this.Board7.Controls.Add(this.PresetD5);
            this.Board7.Controls.Add(this.PresetD6);
            this.Board7.Controls.Add(this.PresetD7);
            this.Board7.Controls.Add(this.Label25);
            this.Board7.Controls.Add(this.lbl_board_7_status);
            this.Board7.Controls.Add(this.PresetD8);
            this.Board7.Controls.Add(this.PictureBox5);
            this.Board7.Location = new System.Drawing.Point(4, 22);
            this.Board7.Name = "Board7";
            this.Board7.Padding = new System.Windows.Forms.Padding(3);
            this.Board7.Size = new System.Drawing.Size(1008, 443);
            this.Board7.TabIndex = 6;
            this.Board7.Text = "Experiment 7";
            this.Board7.UseVisualStyleBackColor = true;
            this.Board7.Click += new System.EventHandler(this.Board7_Click);
            // 
            // ClearCheckBox
            // 
            this.ClearCheckBox.AutoSize = true;
            this.ClearCheckBox.Enabled = false;
            this.ClearCheckBox.Location = new System.Drawing.Point(87, 301);
            this.ClearCheckBox.Name = "ClearCheckBox";
            this.ClearCheckBox.Size = new System.Drawing.Size(15, 14);
            this.ClearCheckBox.TabIndex = 38;
            this.ClearCheckBox.UseVisualStyleBackColor = true;
            // 
            // ClockBox
            // 
            this.ClockBox.Controls.Add(this.ConnectClock);
            this.ClockBox.Controls.Add(this.DisconnectClock);
            this.ClockBox.Location = new System.Drawing.Point(11, 346);
            this.ClockBox.Name = "ClockBox";
            this.ClockBox.Size = new System.Drawing.Size(117, 51);
            this.ClockBox.TabIndex = 37;
            this.ClockBox.TabStop = false;
            this.ClockBox.Text = "Clock";
            // 
            // ConnectClock
            // 
            this.ConnectClock.AutoSize = true;
            this.ConnectClock.Enabled = false;
            this.ConnectClock.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.ConnectClock.Location = new System.Drawing.Point(6, 11);
            this.ConnectClock.Name = "ConnectClock";
            this.ConnectClock.Size = new System.Drawing.Size(95, 17);
            this.ConnectClock.TabIndex = 32;
            this.ConnectClock.TabStop = true;
            this.ConnectClock.Text = "Connect Clock";
            this.ConnectClock.UseVisualStyleBackColor = true;
            // 
            // DisconnectClock
            // 
            this.DisconnectClock.AutoSize = true;
            this.DisconnectClock.Enabled = false;
            this.DisconnectClock.ForeColor = System.Drawing.Color.Red;
            this.DisconnectClock.Location = new System.Drawing.Point(6, 29);
            this.DisconnectClock.Name = "DisconnectClock";
            this.DisconnectClock.Size = new System.Drawing.Size(109, 17);
            this.DisconnectClock.TabIndex = 33;
            this.DisconnectClock.TabStop = true;
            this.DisconnectClock.Text = "Disconnect Clock";
            this.DisconnectClock.UseVisualStyleBackColor = true;
            // 
            // XOR1
            // 
            this.XOR1.Controls.Add(this.ConnectXOR1);
            this.XOR1.Controls.Add(this.BypassXOR1);
            this.XOR1.Location = new System.Drawing.Point(1104, 202);
            this.XOR1.Name = "XOR1";
            this.XOR1.Size = new System.Drawing.Size(72, 51);
            this.XOR1.TabIndex = 36;
            this.XOR1.TabStop = false;
            this.XOR1.Text = "XOR 1";
            // 
            // ConnectXOR1
            // 
            this.ConnectXOR1.AutoSize = true;
            this.ConnectXOR1.Enabled = false;
            this.ConnectXOR1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.ConnectXOR1.Location = new System.Drawing.Point(6, 11);
            this.ConnectXOR1.Name = "ConnectXOR1";
            this.ConnectXOR1.Size = new System.Drawing.Size(60, 17);
            this.ConnectXOR1.TabIndex = 32;
            this.ConnectXOR1.TabStop = true;
            this.ConnectXOR1.Text = "Include";
            this.ConnectXOR1.UseVisualStyleBackColor = true;
            // 
            // BypassXOR1
            // 
            this.BypassXOR1.AutoSize = true;
            this.BypassXOR1.Enabled = false;
            this.BypassXOR1.ForeColor = System.Drawing.Color.Red;
            this.BypassXOR1.Location = new System.Drawing.Point(6, 29);
            this.BypassXOR1.Name = "BypassXOR1";
            this.BypassXOR1.Size = new System.Drawing.Size(59, 17);
            this.BypassXOR1.TabIndex = 33;
            this.BypassXOR1.TabStop = true;
            this.BypassXOR1.Text = "Bypass";
            this.BypassXOR1.UseVisualStyleBackColor = true;
            // 
            // XOR2
            // 
            this.XOR2.Controls.Add(this.ConnectXOR2);
            this.XOR2.Controls.Add(this.BypassXOR2);
            this.XOR2.Location = new System.Drawing.Point(942, 202);
            this.XOR2.Name = "XOR2";
            this.XOR2.Size = new System.Drawing.Size(72, 51);
            this.XOR2.TabIndex = 36;
            this.XOR2.TabStop = false;
            this.XOR2.Text = "XOR 2";
            // 
            // ConnectXOR2
            // 
            this.ConnectXOR2.AutoSize = true;
            this.ConnectXOR2.Enabled = false;
            this.ConnectXOR2.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.ConnectXOR2.Location = new System.Drawing.Point(6, 11);
            this.ConnectXOR2.Name = "ConnectXOR2";
            this.ConnectXOR2.Size = new System.Drawing.Size(60, 17);
            this.ConnectXOR2.TabIndex = 32;
            this.ConnectXOR2.TabStop = true;
            this.ConnectXOR2.Text = "Include";
            this.ConnectXOR2.UseVisualStyleBackColor = true;
            // 
            // BypassXOR2
            // 
            this.BypassXOR2.AutoSize = true;
            this.BypassXOR2.Enabled = false;
            this.BypassXOR2.ForeColor = System.Drawing.Color.Red;
            this.BypassXOR2.Location = new System.Drawing.Point(6, 29);
            this.BypassXOR2.Name = "BypassXOR2";
            this.BypassXOR2.Size = new System.Drawing.Size(59, 17);
            this.BypassXOR2.TabIndex = 33;
            this.BypassXOR2.TabStop = true;
            this.BypassXOR2.Text = "Bypass";
            this.BypassXOR2.UseVisualStyleBackColor = true;
            // 
            // XOR3
            // 
            this.XOR3.Controls.Add(this.ConnectXOR3);
            this.XOR3.Controls.Add(this.BypassXOR3);
            this.XOR3.Location = new System.Drawing.Point(775, 202);
            this.XOR3.Name = "XOR3";
            this.XOR3.Size = new System.Drawing.Size(72, 51);
            this.XOR3.TabIndex = 36;
            this.XOR3.TabStop = false;
            this.XOR3.Text = "XOR 3";
            // 
            // ConnectXOR3
            // 
            this.ConnectXOR3.AutoSize = true;
            this.ConnectXOR3.Enabled = false;
            this.ConnectXOR3.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.ConnectXOR3.Location = new System.Drawing.Point(6, 11);
            this.ConnectXOR3.Name = "ConnectXOR3";
            this.ConnectXOR3.Size = new System.Drawing.Size(60, 17);
            this.ConnectXOR3.TabIndex = 32;
            this.ConnectXOR3.TabStop = true;
            this.ConnectXOR3.Text = "Include";
            this.ConnectXOR3.UseVisualStyleBackColor = true;
            // 
            // BypassXOR3
            // 
            this.BypassXOR3.AutoSize = true;
            this.BypassXOR3.Enabled = false;
            this.BypassXOR3.ForeColor = System.Drawing.Color.Red;
            this.BypassXOR3.Location = new System.Drawing.Point(6, 29);
            this.BypassXOR3.Name = "BypassXOR3";
            this.BypassXOR3.Size = new System.Drawing.Size(59, 17);
            this.BypassXOR3.TabIndex = 33;
            this.BypassXOR3.TabStop = true;
            this.BypassXOR3.Text = "Bypass";
            this.BypassXOR3.UseVisualStyleBackColor = true;
            // 
            // XOR4
            // 
            this.XOR4.Controls.Add(this.ConnectXOR4);
            this.XOR4.Controls.Add(this.BypassXOR4);
            this.XOR4.Location = new System.Drawing.Point(616, 202);
            this.XOR4.Name = "XOR4";
            this.XOR4.Size = new System.Drawing.Size(72, 51);
            this.XOR4.TabIndex = 36;
            this.XOR4.TabStop = false;
            this.XOR4.Text = "XOR 4";
            // 
            // ConnectXOR4
            // 
            this.ConnectXOR4.AutoSize = true;
            this.ConnectXOR4.Enabled = false;
            this.ConnectXOR4.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.ConnectXOR4.Location = new System.Drawing.Point(6, 11);
            this.ConnectXOR4.Name = "ConnectXOR4";
            this.ConnectXOR4.Size = new System.Drawing.Size(60, 17);
            this.ConnectXOR4.TabIndex = 32;
            this.ConnectXOR4.TabStop = true;
            this.ConnectXOR4.Text = "Include";
            this.ConnectXOR4.UseVisualStyleBackColor = true;
            // 
            // BypassXOR4
            // 
            this.BypassXOR4.AutoSize = true;
            this.BypassXOR4.Enabled = false;
            this.BypassXOR4.ForeColor = System.Drawing.Color.Red;
            this.BypassXOR4.Location = new System.Drawing.Point(6, 29);
            this.BypassXOR4.Name = "BypassXOR4";
            this.BypassXOR4.Size = new System.Drawing.Size(59, 17);
            this.BypassXOR4.TabIndex = 33;
            this.BypassXOR4.TabStop = true;
            this.BypassXOR4.Text = "Bypass";
            this.BypassXOR4.UseVisualStyleBackColor = true;
            // 
            // XOR5
            // 
            this.XOR5.Controls.Add(this.ConnectXOR5);
            this.XOR5.Controls.Add(this.BypassXOR5);
            this.XOR5.Location = new System.Drawing.Point(452, 202);
            this.XOR5.Name = "XOR5";
            this.XOR5.Size = new System.Drawing.Size(72, 51);
            this.XOR5.TabIndex = 36;
            this.XOR5.TabStop = false;
            this.XOR5.Text = "XOR 5";
            // 
            // ConnectXOR5
            // 
            this.ConnectXOR5.AutoSize = true;
            this.ConnectXOR5.Enabled = false;
            this.ConnectXOR5.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.ConnectXOR5.Location = new System.Drawing.Point(6, 11);
            this.ConnectXOR5.Name = "ConnectXOR5";
            this.ConnectXOR5.Size = new System.Drawing.Size(60, 17);
            this.ConnectXOR5.TabIndex = 32;
            this.ConnectXOR5.TabStop = true;
            this.ConnectXOR5.Text = "Include";
            this.ConnectXOR5.UseVisualStyleBackColor = true;
            // 
            // BypassXOR5
            // 
            this.BypassXOR5.AutoSize = true;
            this.BypassXOR5.Enabled = false;
            this.BypassXOR5.ForeColor = System.Drawing.Color.Red;
            this.BypassXOR5.Location = new System.Drawing.Point(6, 29);
            this.BypassXOR5.Name = "BypassXOR5";
            this.BypassXOR5.Size = new System.Drawing.Size(59, 17);
            this.BypassXOR5.TabIndex = 33;
            this.BypassXOR5.TabStop = true;
            this.BypassXOR5.Text = "Bypass";
            this.BypassXOR5.UseVisualStyleBackColor = true;
            // 
            // XOR6
            // 
            this.XOR6.Controls.Add(this.ConnectXOR6);
            this.XOR6.Controls.Add(this.BypassXOR6);
            this.XOR6.Location = new System.Drawing.Point(293, 202);
            this.XOR6.Name = "XOR6";
            this.XOR6.Size = new System.Drawing.Size(72, 51);
            this.XOR6.TabIndex = 35;
            this.XOR6.TabStop = false;
            this.XOR6.Text = "XOR 6";
            // 
            // ConnectXOR6
            // 
            this.ConnectXOR6.AutoSize = true;
            this.ConnectXOR6.Enabled = false;
            this.ConnectXOR6.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.ConnectXOR6.Location = new System.Drawing.Point(6, 11);
            this.ConnectXOR6.Name = "ConnectXOR6";
            this.ConnectXOR6.Size = new System.Drawing.Size(60, 17);
            this.ConnectXOR6.TabIndex = 32;
            this.ConnectXOR6.TabStop = true;
            this.ConnectXOR6.Text = "Include";
            this.ConnectXOR6.UseVisualStyleBackColor = true;
            // 
            // BypassXOR6
            // 
            this.BypassXOR6.AutoSize = true;
            this.BypassXOR6.Enabled = false;
            this.BypassXOR6.ForeColor = System.Drawing.Color.Red;
            this.BypassXOR6.Location = new System.Drawing.Point(6, 29);
            this.BypassXOR6.Name = "BypassXOR6";
            this.BypassXOR6.Size = new System.Drawing.Size(59, 17);
            this.BypassXOR6.TabIndex = 33;
            this.BypassXOR6.TabStop = true;
            this.BypassXOR6.Text = "Bypass";
            this.BypassXOR6.UseVisualStyleBackColor = true;
            // 
            // XOR7
            // 
            this.XOR7.Controls.Add(this.ConnectXOR7);
            this.XOR7.Controls.Add(this.BypassXOR7);
            this.XOR7.Location = new System.Drawing.Point(130, 202);
            this.XOR7.Name = "XOR7";
            this.XOR7.Size = new System.Drawing.Size(72, 51);
            this.XOR7.TabIndex = 34;
            this.XOR7.TabStop = false;
            this.XOR7.Text = "XOR 7";
            // 
            // ConnectXOR7
            // 
            this.ConnectXOR7.AutoSize = true;
            this.ConnectXOR7.Enabled = false;
            this.ConnectXOR7.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.ConnectXOR7.Location = new System.Drawing.Point(6, 11);
            this.ConnectXOR7.Name = "ConnectXOR7";
            this.ConnectXOR7.Size = new System.Drawing.Size(60, 17);
            this.ConnectXOR7.TabIndex = 32;
            this.ConnectXOR7.TabStop = true;
            this.ConnectXOR7.Text = "Include";
            this.ConnectXOR7.UseVisualStyleBackColor = true;
            // 
            // BypassXOR7
            // 
            this.BypassXOR7.AutoSize = true;
            this.BypassXOR7.Enabled = false;
            this.BypassXOR7.ForeColor = System.Drawing.Color.Red;
            this.BypassXOR7.Location = new System.Drawing.Point(6, 29);
            this.BypassXOR7.Name = "BypassXOR7";
            this.BypassXOR7.Size = new System.Drawing.Size(59, 17);
            this.BypassXOR7.TabIndex = 33;
            this.BypassXOR7.TabStop = true;
            this.BypassXOR7.Text = "Bypass";
            this.BypassXOR7.UseVisualStyleBackColor = true;
            // 
            // PresetD1
            // 
            this.PresetD1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.PresetD1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PresetD1.Enabled = false;
            this.PresetD1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PresetD1.FormattingEnabled = true;
            this.PresetD1.Items.AddRange(new object[] {
            "1"});
            this.PresetD1.Location = new System.Drawing.Point(1205, 121);
            this.PresetD1.Name = "PresetD1";
            this.PresetD1.Size = new System.Drawing.Size(40, 21);
            this.PresetD1.TabIndex = 24;
            // 
            // PresetD2
            // 
            this.PresetD2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.PresetD2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PresetD2.Enabled = false;
            this.PresetD2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PresetD2.FormattingEnabled = true;
            this.PresetD2.Items.AddRange(new object[] {
            "1"});
            this.PresetD2.Location = new System.Drawing.Point(1044, 121);
            this.PresetD2.Name = "PresetD2";
            this.PresetD2.Size = new System.Drawing.Size(40, 21);
            this.PresetD2.TabIndex = 23;
            // 
            // PresetD3
            // 
            this.PresetD3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.PresetD3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PresetD3.Enabled = false;
            this.PresetD3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PresetD3.FormattingEnabled = true;
            this.PresetD3.Items.AddRange(new object[] {
            "1"});
            this.PresetD3.Location = new System.Drawing.Point(884, 121);
            this.PresetD3.Name = "PresetD3";
            this.PresetD3.Size = new System.Drawing.Size(40, 21);
            this.PresetD3.TabIndex = 22;
            // 
            // PresetD4
            // 
            this.PresetD4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.PresetD4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PresetD4.Enabled = false;
            this.PresetD4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PresetD4.FormattingEnabled = true;
            this.PresetD4.Items.AddRange(new object[] {
            "1"});
            this.PresetD4.Location = new System.Drawing.Point(721, 121);
            this.PresetD4.Name = "PresetD4";
            this.PresetD4.Size = new System.Drawing.Size(40, 21);
            this.PresetD4.TabIndex = 21;
            // 
            // PresetD5
            // 
            this.PresetD5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.PresetD5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PresetD5.Enabled = false;
            this.PresetD5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PresetD5.FormattingEnabled = true;
            this.PresetD5.Items.AddRange(new object[] {
            "1"});
            this.PresetD5.Location = new System.Drawing.Point(560, 121);
            this.PresetD5.Name = "PresetD5";
            this.PresetD5.Size = new System.Drawing.Size(40, 21);
            this.PresetD5.TabIndex = 20;
            // 
            // PresetD6
            // 
            this.PresetD6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.PresetD6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PresetD6.Enabled = false;
            this.PresetD6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PresetD6.FormattingEnabled = true;
            this.PresetD6.Items.AddRange(new object[] {
            "1"});
            this.PresetD6.Location = new System.Drawing.Point(398, 121);
            this.PresetD6.Name = "PresetD6";
            this.PresetD6.Size = new System.Drawing.Size(40, 21);
            this.PresetD6.TabIndex = 19;
            // 
            // PresetD7
            // 
            this.PresetD7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.PresetD7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PresetD7.Enabled = false;
            this.PresetD7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PresetD7.FormattingEnabled = true;
            this.PresetD7.Items.AddRange(new object[] {
            "1"});
            this.PresetD7.Location = new System.Drawing.Point(237, 121);
            this.PresetD7.Name = "PresetD7";
            this.PresetD7.Size = new System.Drawing.Size(40, 21);
            this.PresetD7.TabIndex = 18;
            // 
            // Label25
            // 
            this.Label25.AutoSize = true;
            this.Label25.Location = new System.Drawing.Point(542, 17);
            this.Label25.Name = "Label25";
            this.Label25.Size = new System.Drawing.Size(172, 13);
            this.Label25.TabIndex = 17;
            this.Label25.Text = "Learning to Use the Logic Analyzer";
            // 
            // lbl_board_7_status
            // 
            this.lbl_board_7_status.AutoSize = true;
            this.lbl_board_7_status.BackColor = System.Drawing.Color.Red;
            this.lbl_board_7_status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_board_7_status.ForeColor = System.Drawing.Color.White;
            this.lbl_board_7_status.Location = new System.Drawing.Point(6, 26);
            this.lbl_board_7_status.Name = "lbl_board_7_status";
            this.lbl_board_7_status.Size = new System.Drawing.Size(47, 15);
            this.lbl_board_7_status.TabIndex = 16;
            this.lbl_board_7_status.Text = "Inactive";
            // 
            // PresetD8
            // 
            this.PresetD8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.PresetD8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PresetD8.Enabled = false;
            this.PresetD8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PresetD8.FormattingEnabled = true;
            this.PresetD8.Items.AddRange(new object[] {
            "1"});
            this.PresetD8.Location = new System.Drawing.Point(75, 121);
            this.PresetD8.Name = "PresetD8";
            this.PresetD8.Size = new System.Drawing.Size(40, 21);
            this.PresetD8.TabIndex = 8;
            // 
            // PictureBox5
            // 
            this.PictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox5.Image")));
            this.PictureBox5.Location = new System.Drawing.Point(3, 44);
            this.PictureBox5.Name = "PictureBox5";
            this.PictureBox5.Size = new System.Drawing.Size(1271, 364);
            this.PictureBox5.TabIndex = 3;
            this.PictureBox5.TabStop = false;
            this.PictureBox5.Click += new System.EventHandler(this.PictureBox5_Click);
            // 
            // PrintDialog1
            // 
            this.PrintDialog1.UseEXDialog = true;
            // 
            // lbl_serial
            // 
            this.lbl_serial.AutoSize = true;
            this.lbl_serial.Location = new System.Drawing.Point(228, 24);
            this.lbl_serial.Name = "lbl_serial";
            this.lbl_serial.Size = new System.Drawing.Size(96, 13);
            this.lbl_serial.TabIndex = 5;
            this.lbl_serial.Text = "Serial Port Monitor:";
            // 
            // btn_test_2
            // 
            this.btn_test_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_test_2.Location = new System.Drawing.Point(816, 19);
            this.btn_test_2.Name = "btn_test_2";
            this.btn_test_2.Size = new System.Drawing.Size(87, 23);
            this.btn_test_2.TabIndex = 4;
            this.btn_test_2.Text = "Logic Analyzer";
            this.btn_test_2.UseVisualStyleBackColor = true;
            this.btn_test_2.Click += new System.EventHandler(this.btn_test_2_Click);
            // 
            // btn_Dev_Test
            // 
            this.btn_Dev_Test.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Dev_Test.Location = new System.Drawing.Point(603, 19);
            this.btn_Dev_Test.Name = "btn_Dev_Test";
            this.btn_Dev_Test.Size = new System.Drawing.Size(207, 23);
            this.btn_Dev_Test.TabIndex = 3;
            this.btn_Dev_Test.Text = "Oscilloscope/Function Generator";
            this.btn_Dev_Test.UseVisualStyleBackColor = true;
            this.btn_Dev_Test.Click += new System.EventHandler(this.btn_Dev_Test_Click);
            // 
            // Serial_Text_Test
            // 
            this.Serial_Text_Test.Location = new System.Drawing.Point(330, 19);
            this.Serial_Text_Test.Multiline = false;
            this.Serial_Text_Test.Name = "Serial_Text_Test";
            this.Serial_Text_Test.ReadOnly = true;
            this.Serial_Text_Test.Size = new System.Drawing.Size(255, 23);
            this.Serial_Text_Test.TabIndex = 2;
            this.Serial_Text_Test.Text = "";
            // 
            // btn_Send_Config
            // 
            this.btn_Send_Config.BackColor = System.Drawing.Color.LightBlue;
            this.btn_Send_Config.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Send_Config.Location = new System.Drawing.Point(117, 19);
            this.btn_Send_Config.Name = "btn_Send_Config";
            this.btn_Send_Config.Size = new System.Drawing.Size(105, 23);
            this.btn_Send_Config.TabIndex = 1;
            this.btn_Send_Config.Text = "Update Board";
            this.btn_Send_Config.UseVisualStyleBackColor = false;
            this.btn_Send_Config.Click += new System.EventHandler(this.btn_Send_Config_Click);
            // 
            // CommControlGroup
            // 
            this.CommControlGroup.Controls.Add(this.button1);
            this.CommControlGroup.Controls.Add(this.lbl_serial);
            this.CommControlGroup.Controls.Add(this.btn_test_2);
            this.CommControlGroup.Controls.Add(this.btn_Dev_Test);
            this.CommControlGroup.Controls.Add(this.Serial_Text_Test);
            this.CommControlGroup.Controls.Add(this.btn_Send_Config);
            this.CommControlGroup.Controls.Add(this.board_detect);
            this.CommControlGroup.Cursor = System.Windows.Forms.Cursors.Default;
            this.CommControlGroup.Location = new System.Drawing.Point(17, 17);
            this.CommControlGroup.Name = "CommControlGroup";
            this.CommControlGroup.Size = new System.Drawing.Size(1016, 65);
            this.CommControlGroup.TabIndex = 6;
            this.CommControlGroup.TabStop = false;
            this.CommControlGroup.Text = "Communication Control";
            this.CommControlGroup.Resize += new System.EventHandler(this.CommControlGroup_Resize);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(909, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Logic Analyzer 2";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // board_detect
            // 
            this.board_detect.BackColor = System.Drawing.Color.LightBlue;
            this.board_detect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.board_detect.Location = new System.Drawing.Point(15, 19);
            this.board_detect.Name = "board_detect";
            this.board_detect.Size = new System.Drawing.Size(96, 23);
            this.board_detect.TabIndex = 0;
            this.board_detect.Text = "Check Board ";
            this.board_detect.UseVisualStyleBackColor = false;
            this.board_detect.Click += new System.EventHandler(this.board_detect_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1008, 443);
            this.tabPage1.TabIndex = 8;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(812, 78);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 0;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1044, 569);
            this.Controls.Add(this.Setup);
            this.Controls.Add(this.CommControlGroup);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Remote_EE_Lab";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing_1);
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
            this.board_2_Ch_1.ResumeLayout(false);
            this.board_2_Ch_1.PerformLayout();
            this.board_2_ch2.ResumeLayout(false);
            this.board_2_ch2.PerformLayout();
            this.Diode1.ResumeLayout(false);
            this.Diode1.PerformLayout();
            this.board_2_Circuit_Control.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox6)).EndInit();
            this.Board_2.ResumeLayout(false);
            this.Board_2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.board_2_chematic)).EndInit();
            this.Diode2.ResumeLayout(false);
            this.Diode2.PerformLayout();
            this.Circuit_Controls.ResumeLayout(false);
            this.brd_1_ch2.ResumeLayout(false);
            this.brd_1_ch2.PerformLayout();
            this.brd_1_ch1.ResumeLayout(false);
            this.brd_1_ch1.PerformLayout();
            this.Setup.ResumeLayout(false);
            this.Board_1.ResumeLayout(false);
            this.Board_1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Board_1_Image)).EndInit();
            this.Board3.ResumeLayout(false);
            this.Board3.PerformLayout();
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            this.Board4.ResumeLayout(false);
            this.Board4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            this.Board5.ResumeLayout(false);
            this.Board5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            this.Board6.ResumeLayout(false);
            this.Board6.PerformLayout();
            this.ResetZ80.ResumeLayout(false);
            this.SelectProgram.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).EndInit();
            this.Board7.ResumeLayout(false);
            this.Board7.PerformLayout();
            this.ClockBox.ResumeLayout(false);
            this.ClockBox.PerformLayout();
            this.XOR1.ResumeLayout(false);
            this.XOR1.PerformLayout();
            this.XOR2.ResumeLayout(false);
            this.XOR2.PerformLayout();
            this.XOR3.ResumeLayout(false);
            this.XOR3.PerformLayout();
            this.XOR4.ResumeLayout(false);
            this.XOR4.PerformLayout();
            this.XOR5.ResumeLayout(false);
            this.XOR5.PerformLayout();
            this.XOR6.ResumeLayout(false);
            this.XOR6.PerformLayout();
            this.XOR7.ResumeLayout(false);
            this.XOR7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox5)).EndInit();
            this.CommControlGroup.ResumeLayout(false);
            this.CommControlGroup.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label board_2_lbl_C1;
        internal System.Windows.Forms.ComboBox board_2_C1;
        internal System.Windows.Forms.ComboBox board_2_R4;
        internal System.Windows.Forms.Label board_2_lbl_C2;
        internal System.Windows.Forms.Label board_2_lbl_R4;
        internal System.Windows.Forms.ComboBox board_2_C2;
        internal System.Windows.Forms.ComboBox board_2_R3;
        internal System.Windows.Forms.Label board_2_lbl_R2;
        internal System.Windows.Forms.Label board_2_lbl3;
        internal System.Windows.Forms.ComboBox board_2_scope_ch_1_gain;
        internal System.Windows.Forms.Label board_2_lbl_2;
        internal System.Windows.Forms.Label board_2_lbl1;
        internal System.Windows.Forms.GroupBox board_2_Ch_1;
        internal System.Windows.Forms.Label board_2_lbl_R3;
        internal System.Windows.Forms.GroupBox board_2_ch2;
        internal System.Windows.Forms.Label board_2_lbl6;
        internal System.Windows.Forms.ComboBox board_2_scope_ch_2_gain;
        internal System.Windows.Forms.Label board_2_lbl5;
        internal System.Windows.Forms.Label board_2_lbl4;
        internal System.Windows.Forms.Button board_3_multimeter_refresh;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label lbl_board_4_status;
        internal System.Windows.Forms.ComboBox board_4_R1;
        internal System.Windows.Forms.RichTextBox board_3_multimeter_output;
        internal System.Windows.Forms.Label Label31;
        internal System.Windows.Forms.GroupBox Diode1;
        internal System.Windows.Forms.RadioButton board4_Diode1_RadioButton2;
        internal System.Windows.Forms.RadioButton board4_Diode1_RadioButton1;
        internal System.Windows.Forms.Label lbl_board_3_status;
        internal System.Windows.Forms.GroupBox board_2_Circuit_Control;
        internal System.Windows.Forms.ComboBox board_3_R3;
        internal System.Windows.Forms.ComboBox board_3_R2;
        internal System.Windows.Forms.PictureBox PictureBox6;
        internal System.Windows.Forms.TabPage Board_2;
        internal System.Windows.Forms.Label lbl_board_2;
        internal System.Windows.Forms.Label lbl_board_2_status;
        internal System.Windows.Forms.ComboBox board_2_R2;
        internal System.Windows.Forms.ComboBox board_2_R1;
        internal System.Windows.Forms.Label board_2_lbl_R1;
        internal System.Windows.Forms.PictureBox board_2_chematic;
        internal System.Windows.Forms.GroupBox Diode2;
        internal System.Windows.Forms.RadioButton board4_Diode2_RadioButton2;
        internal System.Windows.Forms.RadioButton board4_Diode2_RadioButton1;
        internal System.Windows.Forms.Label lbl_board_1_status;
        internal System.Windows.Forms.GroupBox Circuit_Controls;
        internal System.Windows.Forms.GroupBox brd_1_ch2;
        internal System.Windows.Forms.Label board_1_lbl_2;
        internal System.Windows.Forms.ComboBox brd_1_ch_2_gain;
        internal System.Windows.Forms.Label lbl_gain_2;
        internal System.Windows.Forms.ComboBox Brd_1_Scope_Ch2;
        internal System.Windows.Forms.Label lbl_Scope_1;
        internal System.Windows.Forms.GroupBox brd_1_ch1;
        internal System.Windows.Forms.Label board_1_lbl_1;
        internal System.Windows.Forms.ComboBox brd_1_ch1_gain;
        internal System.Windows.Forms.Label lbl_gain_1;
        internal System.Windows.Forms.Label lbl_scope;
        internal System.Windows.Forms.ComboBox Brd_1_Scope;
        internal System.Windows.Forms.TabControl Setup;
        internal System.Windows.Forms.TabPage Board_1;
        internal System.Windows.Forms.Label lbl5k_1;
        internal System.Windows.Forms.Label lbl_board_1;
        internal System.Windows.Forms.Label lbl_5k;
        internal System.Windows.Forms.Label lbl_1k;
        internal System.Windows.Forms.ComboBox Brd_1_Res_Select;
        internal System.Windows.Forms.Label Lbl_19k;
        internal System.Windows.Forms.Label lbl_A;
        internal System.Windows.Forms.ComboBox board_1_R3_enable;
        internal System.Windows.Forms.Label lbl_B;
        internal System.Windows.Forms.Label lbl_D;
        internal System.Windows.Forms.Label lbl_C;
        internal System.Windows.Forms.PictureBox Board_1_Image;
        internal System.Windows.Forms.TabPage Board3;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.TabPage Board4;
        internal System.Windows.Forms.PictureBox PictureBox1;
        internal System.Windows.Forms.TabPage Board5;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label lbl_board_5_status;
        internal System.Windows.Forms.ComboBox board_5_R3;
        internal System.Windows.Forms.ComboBox board_5_R2;
        internal System.Windows.Forms.ComboBox board_5_C1;
        internal System.Windows.Forms.PictureBox PictureBox3;
        internal System.Windows.Forms.TabPage Board6;
        internal System.Windows.Forms.GroupBox ResetZ80;
        internal System.Windows.Forms.Button ResetZ80_Button;
        internal System.Windows.Forms.GroupBox SelectProgram;
        internal System.Windows.Forms.ComboBox ProgramSelector;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.Label lbl_board_6_status;
        internal System.Windows.Forms.PictureBox PictureBox4;
        internal System.Windows.Forms.TabPage Board7;
        internal System.Windows.Forms.CheckBox ClearCheckBox;
        internal System.Windows.Forms.GroupBox ClockBox;
        internal System.Windows.Forms.RadioButton ConnectClock;
        internal System.Windows.Forms.RadioButton DisconnectClock;
        internal System.Windows.Forms.GroupBox XOR1;
        internal System.Windows.Forms.RadioButton ConnectXOR1;
        internal System.Windows.Forms.RadioButton BypassXOR1;
        internal System.Windows.Forms.GroupBox XOR2;
        internal System.Windows.Forms.RadioButton ConnectXOR2;
        internal System.Windows.Forms.RadioButton BypassXOR2;
        internal System.Windows.Forms.GroupBox XOR3;
        internal System.Windows.Forms.RadioButton ConnectXOR3;
        internal System.Windows.Forms.RadioButton BypassXOR3;
        internal System.Windows.Forms.GroupBox XOR4;
        internal System.Windows.Forms.RadioButton ConnectXOR4;
        internal System.Windows.Forms.RadioButton BypassXOR4;
        internal System.Windows.Forms.GroupBox XOR5;
        internal System.Windows.Forms.RadioButton ConnectXOR5;
        internal System.Windows.Forms.RadioButton BypassXOR5;
        internal System.Windows.Forms.GroupBox XOR6;
        internal System.Windows.Forms.RadioButton ConnectXOR6;
        internal System.Windows.Forms.RadioButton BypassXOR6;
        internal System.Windows.Forms.GroupBox XOR7;
        internal System.Windows.Forms.RadioButton ConnectXOR7;
        internal System.Windows.Forms.RadioButton BypassXOR7;
        internal System.Windows.Forms.ComboBox PresetD1;
        internal System.Windows.Forms.ComboBox PresetD2;
        internal System.Windows.Forms.ComboBox PresetD3;
        internal System.Windows.Forms.ComboBox PresetD4;
        internal System.Windows.Forms.ComboBox PresetD5;
        internal System.Windows.Forms.ComboBox PresetD6;
        internal System.Windows.Forms.ComboBox PresetD7;
        internal System.Windows.Forms.Label Label25;
        internal System.Windows.Forms.Label lbl_board_7_status;
        internal System.Windows.Forms.ComboBox PresetD8;
        internal System.Windows.Forms.PictureBox PictureBox5;
        internal System.Windows.Forms.PrintDialog PrintDialog1;
        internal System.IO.Ports.SerialPort SerialPort1;
        internal System.Windows.Forms.Label lbl_serial;
        internal System.Windows.Forms.Button btn_test_2;
        internal System.Windows.Forms.Button btn_Dev_Test;
        internal System.Windows.Forms.RichTextBox Serial_Text_Test;
        internal System.Windows.Forms.Button btn_Send_Config;
        internal System.Windows.Forms.GroupBox CommControlGroup;
        internal System.Windows.Forms.Button board_detect;
        internal System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button2;
    }
}

