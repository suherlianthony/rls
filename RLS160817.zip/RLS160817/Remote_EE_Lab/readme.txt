This is the GUI created in Visual Basic.
