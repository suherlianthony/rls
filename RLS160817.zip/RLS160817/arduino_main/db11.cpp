#include "Arduino.h"
#include "db11.h"


const int switch1_in1 = 32; // Connect or bypass XOR7
const int switch1_in2 = 9;
const int switch1_in3 = 10;
const int switch2_in1 = 43;
const int switch2_in2 = 44;
const int switch2_in3 = 45;
const int pot_inc = 29;
const int pot_ud = 30;
const int pot_cs = 31;
int selected = 0;
int opamp = 0;
int pot_r = 0;
int requested = 0; 
int current = 0;
int iteration = 0;

void DB11::configurePins() {
  pinMode(switch1_in1, OUTPUT);
  pinMode(switch1_in2, OUTPUT);
  pinMode(switch1_in3, OUTPUT);
  pinMode(switch2_in1, OUTPUT);
  pinMode(switch2_in2, OUTPUT);
  pinMode(switch2_in3, OUTPUT);
  pinMode(pot_inc,OUTPUT);
  pinMode(pot_ud,OUTPUT);
  pinMode(pot_cs, OUTPUT); 

}

void DB11::execute(String Board_11_Serial) {
  // variables used for parsing input from interface
  // the default message is board_11,0,0;
  selected = Board_11_Serial.substring(9,10).toInt();
  opamp = Board_11_Serial.substring(11,12).toInt();
  switch(selected){
    case 1:
      requested = 100;
      break;
    case2:
      requested = 500;
      break;
    case 3:
      requested = 1000;
      break;
    case 4: 
      requested = 5000;
      break;
    case 5: 
      requested = 10000;
      break;
  }
  if ( current < requested) 
  {
    iteration = round((requested-current)/100);
    for(int i = 0; iteration; i++)
    {
      digitalWrite(pot_cs,LOW);
      delay(1);
      digitalWrite(pot_ud,HIGH);
      delay(1);
      digitalWrite(pot_inc,LOW);
      delay(1);
      digitalWrite(pot_inc,HIGH);
      delay(1);
      current += 100;
      delay(1000);
    }
  }
  else if( requested < current)
  {
    iteration =round((current-requested)/100);
    for(int i = 0; iteration; i++)
    {
      digitalWrite(pot_cs,LOW);
      delay(1);
      digitalWrite(pot_ud,LOW);
      delay(1);
      digitalWrite(pot_inc,LOW);
      delay(1);
      digitalWrite(pot_inc,HIGH);
      delay(1);
      current -= 100;
      delay(1000);
    }
  }
  
  if (opamp == 1)
  {
    digitalWrite(switch1_in2,LOW);
    digitalWrite(switch1_in3,LOW);
    digitalWrite(switch2_in2,LOW);
    digitalWrite(switch2_in3,LOW);
    digitalWrite(switch1_in2,LOW);
    digitalWrite(switch1_in1,HIGH);
    digitalWrite(switch2_in1,HIGH);
  }
  else if(opamp == 2)
  {

    digitalWrite(switch1_in3,LOW);
    digitalWrite(switch2_in3,LOW);
    digitalWrite(switch1_in2,LOW);
    digitalWrite(switch1_in1,LOW);
    digitalWrite(switch2_in1,LOW);
    digitalWrite(switch2_in2,HIGH);
    digitalWrite(switch1_in2,HIGH);
  }
  else if(opamp == 3)
  {
    digitalWrite(switch1_in2,LOW);
    digitalWrite(switch2_in2,LOW);
    digitalWrite(switch1_in2,LOW);
    digitalWrite(switch1_in1,LOW);
    digitalWrite(switch2_in1,LOW);
    digitalWrite(switch2_in3,HIGH);
    digitalWrite(switch1_in3,HIGH);
  }
  }

