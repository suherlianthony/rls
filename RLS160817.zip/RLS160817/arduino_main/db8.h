/******************************************************************************
  DigitalPot.h
  This header file contains code to control the negative and positive set of
  digital potentiometers based on a daughterboard requested input voltage.

  Created by Paolo Sebastian, July 2017
  Reseased into the public domain.
******************************************************************************/
#include "Arduino.h"

class DB8
{
  public: 
  void execute(String);
  void configurePins();  

  private: 
    const int pot_inc = 29;
    const int pot_ud = 30;
    const int pot_cs = 31;
    const int pot0_inc = 29;
    const int pot0_ud = 30;
    const int pot0_cs = 31;
};

