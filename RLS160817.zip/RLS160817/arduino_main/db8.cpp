#include "Arduino.h"
#include "db8.h"
#include <SPI.h>

const int pot_inc = 41;
const int pot_ud = 40;
const int pot_cs = 44;
const int pot0_inc = 38;
const int pot0_ud = 37;
const int pot0_cs = 36;
const int SPIselect = 32;
const int spiSCK = 52;
const int SPIsi = 51;
int poty_r = 0;
int pot0_r = 0;
int requestedy = 0;
int currenty = 0;
int iterationy = 0;
int requested0 = 0;
int current0 = 0;
int iteration0 = 0;
int spiRes = 0;
int currentSPI = 0;
  
void DB8::configurePins() {
  pinMode(pot_inc, OUTPUT);
  pinMode(pot_ud, OUTPUT);
  pinMode(pot_cs, OUTPUT);
  pinMode(pot0_inc, OUTPUT);
  pinMode(pot0_ud, OUTPUT);
  pinMode(pot0_cs, OUTPUT);
}

void DB8::execute(String Board_8_Serial) {
  // variables used for parsing input from interface
  // the default message is board_8,0,xxxxx;
  poty_r = Board_8_Serial.substring(8,9).toInt();
  pot0_r = Board_8_Serial.substring(10).toInt();
  spiRes = (pot0_r%1000)/3.90625;

  digitalWrite(SPIselect,LOW);
  SPI.transfer(B00010001);
  SPI.transfer(spiRes);
  digitalWrite(SPIselect,HIGH);
 
  if ( current0 < pot0_r)
  {
    iteration0 = round((pot0_r - current0) / 500);
    for (int i = 0; iteration0; i++)
    {
      digitalWrite(pot0_cs, LOW);
      delay(1);
      digitalWrite(pot0_ud, HIGH);
      delay(1);
      digitalWrite(pot0_inc, LOW);
      delay(1);
      digitalWrite(pot0_inc, HIGH);
      delay(1);
      current0 += 500;
      delay(1000);
    }
  }
  else if ( pot0_r < current0)
  {
    iteration0 = round((current0 - pot0_r) / 500);
    for (int i = 0; iteration0; i++)
    {
      digitalWrite(pot0_cs, LOW);
      delay(1);
      digitalWrite(pot0_ud, LOW);
      delay(1);
      digitalWrite(pot0_inc, LOW);
      delay(1);
      digitalWrite(pot0_inc, HIGH);
      delay(1);
      current0 -= 500;
      delay(1000);
    }
  }

switch (poty_r) {
 case 1:
     requestedy = 500;
     break;
  case 2:
     requestedy = 1000;
    break;
  case 3:
    requestedy = 2000;
     break;

 }

if ( currenty < requestedy)
 {
  iterationy = round((requestedy - currenty) / 100);
  for (int i = 0; iterationy; i++)
  {
    digitalWrite(pot_cs, LOW);
    delay(1);
     digitalWrite(pot_ud, HIGH);
     delay(1);
      digitalWrite(pot_inc, LOW);
     delay(1);
      digitalWrite(pot_inc, HIGH);
      delay(1);
      currenty += 100;
      delay(1000);
    }
  }
   else if ( requestedy < currenty)
  {
   iterationy = round((requestedy - currenty) / 100);
    for (int i = 0; iterationy; i++)
    {
      digitalWrite(pot_cs, LOW);
     delay(1);
     digitalWrite(pot_ud, LOW);
      delay(1);
     digitalWrite(pot_inc, LOW);
      delay(1);
      digitalWrite(pot_inc, HIGH);
     delay(1);
      currenty -= 100;
      delay(1000);
    }
  }
}


