#ifndef db11_h
#define db11_h

#include "Arduino.h"

class DB11 {
  public: 
  void execute(String);
  void configurePins();
  
  private:
  const int switch1_in1 = 32; // Connect or bypass XOR7
  const int switch1_in2 = 9;
  const int switch1_in3 = 10;
  const int switch2_in1 = 43;
  const int switch2_in2 = 44;
  const int switch2_in3 = 45;
  const int pot_inc = 29;
  const int pot_ud = 30;
  const int pot_cs = 31;
  // variables used for parsing input from user interface
};

#endif
