#include "Arduino.h"
#include "db9.h"

//
//const int switch1_in1 = 26;
//const int switch1_in2 = 28;
//const int switch2_in1 = 32;
//const int switch2_in2 = 33;
//const int switch2_in3 = 34;
int experiment = 0;
int capacitorx = 0;
int resistorx = 0;
//const int pot_inc = 13 ;
//const int pot_ud = 12;
//const int pot_cs = 44;
 int requestedx = 0; 
 int currentx = 0;
 int iterationx = 0;

void DB9::configurePins() {
  pinMode(switch1_in1, OUTPUT);
  pinMode(switch1_in2, OUTPUT);
  pinMode(switch2_in1, OUTPUT);
  pinMode(switch2_in2, OUTPUT);
  pinMode(switch2_in3, OUTPUT);
  pinMode(pot_inc,OUTPUT);
  pinMode(pot_ud,OUTPUT);
  pinMode(pot_cs, OUTPUT);
}


void DB9::execute(String Board_9_Serial) {
  // variables used for parsing input from interface
  // the default message is board_9,0,0,0;
  experiment = Board_9_Serial.substring(8,9).toInt();
  capacitorx = Board_9_Serial.substring(10,11).toInt();
  resistorx = Board_9_Serial.substring(12,13).toInt();
  switch(resistorx){
    case 1:
      requestedx = 500;
      break;
    case 2:
      requestedx = 1000;
      break;
    case 3:
      requestedx = 2000;
      break;
  }
  switch(capacitorx)
  {
   case 1:
      digitalWrite(switch2_in2,LOW);
      digitalWrite(switch2_in3,LOW);
      digitalWrite(switch2_in1,HIGH);
      break;
   case 2:
      digitalWrite(switch2_in3,LOW);
      digitalWrite(switch2_in1,LOW);
      digitalWrite(switch2_in2,HIGH);
   case 3:  
      digitalWrite(switch2_in1,LOW);
      digitalWrite(switch2_in2,LOW);
      digitalWrite(switch2_in3,HIGH);

  }
  if ( currentx < requestedx) 
  {
    iterationx = round((requestedx-currentx)/100);
    for(int i = 0; iterationx; i++)
    {
      digitalWrite(pot_cs,LOW);
      delay(1);
      digitalWrite(pot_ud,HIGH);
      delay(1);
      digitalWrite(pot_inc,LOW);
      delay(1);
      digitalWrite(pot_inc,HIGH);
      delay(1);
      currentx += 100;
      delay(1000);
    }
  }
  else if( requestedx < currentx)
  {
    iterationx =round((currentx-requestedx)/100);
    for(int i = 0; iterationx; i++)
    {
      digitalWrite(pot_cs,LOW);
      delay(1);
      digitalWrite(pot_ud,LOW);
      delay(1);
      digitalWrite(pot_inc,LOW);
      delay(1);
      digitalWrite(pot_inc,HIGH);
      delay(1);
      currentx -= 100;
      delay(1000);
    }
  }
  
  if (experiment == 1)
  {
    digitalWrite(switch1_in2,LOW);
    digitalWrite(switch1_in1,HIGH);

  }
  else if(experiment == 2)
  {

    digitalWrite(switch1_in1,LOW);
    digitalWrite(switch1_in2,HIGH);
  }
}

