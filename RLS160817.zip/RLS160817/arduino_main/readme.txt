This is the arduino code.
