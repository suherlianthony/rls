#ifndef db9_h
#define db9_h

class DB9 {
  public:
    void execute(String);
    void configurePins();

  private:
    const int switch1_in1 = 26;
    const int switch1_in2 = 28;
    const int switch2_in1 = 32;
    const int switch2_in2 = 33;
    const int switch2_in3 = 34;
    const int pot_inc = 13 ;
    const int pot_ud = 12;
    const int pot_cs = 44;

};

#endif
